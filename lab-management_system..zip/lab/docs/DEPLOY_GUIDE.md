# Deploy from zero (real users) with automatic updates

This guide takes you from the project folder on your computer to a live website that **updates itself every time you push a change**. Data is kept in Supabase, so redeploys never delete users or complaints.

**What you need:** the project folder, Node.js 22.5+, Git, and free accounts at GitHub, Supabase and Render (Resend later, for email).

---

## Step 0. Choose your plans (this decides how reliable it is)

| Piece | Free option | What it means for real users | Paid option |
|---|---|---|---|
| Render (runs the app) | Free web service | Sleeps after 15 minutes without visitors, so the next person waits about 30 seconds | Starter, from about $7/month, always on |
| Supabase (database) | Free project | Paused after a week with little activity; you must resume it by hand. No daily backups on the free plan | Pro, about $25/month: cannot be paused, daily backups kept 7 days |

For a short pilot the free plans are fine **if people use the app every day**. For a whole college, use at least Render Starter, and move Supabase to Pro before you hold data you cannot lose. Prices change, so check both pricing pages.

---

## Step 1. Check the project on your computer (once)

```
npm install            # installs the one dependency (pg) and creates package-lock.json
npm test               # expect: All 87 checks passed
npm run test:pg        # expect: All 87 checks passed
```
Open `.gitignore` and confirm it lists `.env`, `node_modules` and `*.db`. Those must never go to GitHub.

---

## Step 2. Put the code on GitHub

1. On github.com create a **private** repository (for example `smart-lab`). Leave it empty.
2. In the project folder (the terminal in Antigravity works):
   ```
   git init
   git add .
   git commit -m "First version"
   git branch -M main
   git remote add origin https://github.com/YOUR-NAME/smart-lab.git
   git push -u origin main
   ```
3. Check on GitHub that there is **no `.env` file** in the repository. If there is, delete it and change every password it contained.

The included GitHub Actions workflow now runs the tests on every push.

---

## Step 3. Get your Supabase connection string

1. Supabase dashboard, open your project, click **Connect**.
2. Choose **Session pooler** and copy the connection string (it works on hosts that only have IPv4, such as Render).
3. Replace `[YOUR-PASSWORD]` with your database password. If you forgot it: Project Settings, Database, Reset database password.
4. Keep this string secret. You will paste it into Render in Step 4, and nowhere else.

The tables already exist in your project (the app also creates any missing ones on start).

---

## Step 4. Create the service on Render

*Why Render:* simplest path for this project (it reads `render.yaml`, builds the Dockerfile, and redeploys on every push). Other hosts (for example AWS Mumbai or a VPS in India) also work with the same Dockerfile; the steps differ only in where you click.

1. Sign up at render.com with GitHub and allow access to your repository.
2. Click **New, Blueprint**, pick the repository. Render reads `render.yaml`.
3. Fill in the settings it asks for:

| Setting | Value |
|---|---|
| `DATABASE_URL` | the Supabase string from Step 3 |
| `ADMIN_USERNAME` | the username for your first admin, for example `lab.admin` |
| `ADMIN_PASSWORD` | a strong password, at least 8 characters |
| `BASE_URL` | leave empty for now |

`SESSION_SECRET` is generated for you and `TRUST_PROXY` is already set. Never change `SESSION_SECRET` later, or everyone is logged out.

4. Check that the region is **Singapore** (the Blueprint sets it). It is the closest Render region to India and to your Mumbai Supabase database, and Render cannot change a service's region later.
5. Click **Apply**. The first build takes a few minutes.
6. Render gives you an address like `https://smart-lab.onrender.com`.

---

## Step 5. First checks (5 minutes)

1. Open `https://YOUR-ADDRESS/api/health`. It must show `"db":"postgres"`. If it says `sqlite`, your `DATABASE_URL` is not being used, and data would be lost at the next restart. Fix this before anything else.
2. Open the site and log in with the admin username and password from Step 4.
3. **Settings, Branding:** upload your college logo (only one you have the right to use) and the college name.
4. **Settings, Registration:** keep it open, and add your college email domain (for example `jspm.edu`) so only college addresses can sign up.
5. In another browser, register a student, approve them as admin, and walk one complaint through the whole workflow.
6. Optional but recommended: remove `ADMIN_PASSWORD` from the Render environment settings now that the admin exists.

---

## Step 6. Turn on email (so password resets work)

1. Create an account at resend.com and an API key.
2. Verify your sending domain in Resend. Until you do, Resend only delivers to your own address.
3. In Render, Environment, add `RESEND_API_KEY`, `MAIL_FROM` (an address on the verified domain) and `BASE_URL` (your site address from Step 4).
4. Render redeploys. In **Settings, Email**, click **Send test email to me** and check your inbox.

---

## Step 7. How updates work from now on

Render deploys automatically whenever you push to the connected branch (`main`). The Blueprint sets this explicitly (`autoDeployTrigger: commit`).

Your routine for every change:
```
npm test && npm run test:pg      # both must pass
git add -A
git commit -m "Describe the change"
git push
```
Then watch the deploy in the Render dashboard (the **Events** or **Logs** tab).

- **Users and complaints are not touched.** They live in Supabase.
- **A broken version does not go live.** Render checks `/api/health` before switching over; if the check fails, the previous version stays running.
- **Brief interruption:** during a deploy there can be a short gap, so push outside busy hours.
- **Safer option:** in the Render service settings (Build and Deploy, Auto-Deploy) you can choose to deploy only after the GitHub checks pass, so a failing test never deploys. Check the exact wording in the dashboard.
- **Database changes:** the app creates missing tables on start. If a future change adds a *column* to an existing table, it must be added to `db/postgres-schema.sql` as `ALTER TABLE ... ADD COLUMN IF NOT EXISTS ...` so it is applied on the next start. Ask for this whenever you request a change that stores new information.
- **Rolling back:** the safest way is `git revert HEAD` followed by `git push`. You can also redeploy an earlier deploy from the Render dashboard.
- **Changing a setting:** edit it under Environment in Render. Saving triggers a redeploy.

---

## Step 8. Keep it healthy

- **Uptime alerts:** add a free monitor (for example UptimeRobot) on `https://YOUR-ADDRESS/api/health` that emails you when it fails. The health check also reads the database, which counts as activity for Supabase.
- **Backups:** on Supabase Pro, daily backups are kept for 7 days. On the free plan, take your own copy regularly with `pg_dump "YOUR_DATABASE_URL" > backup.sql` (needs the PostgreSQL client tools), and store it somewhere safe. Practise restoring one before you need it.
- **Custom address** (for example `labs.yourcollege.edu`): add it in Render's service settings, create the DNS record Render shows, then update `BASE_URL`. Check that your Render plan includes custom domains.
- **Privacy:** add a short notice saying what you store (names, emails, complaint photos), who can see it and who to contact. Check India's DPDP Act duties with someone qualified.

---

## If something goes wrong

| Problem | Fix |
|---|---|
| Deploy fails, log says `SESSION_SECRET is required` | The variable is missing; add it (the Blueprint normally generates it) |
| Log says `Empty database: set ADMIN_USERNAME...` | The database is empty and the admin settings are missing; add `ADMIN_USERNAME` and `ADMIN_PASSWORD` |
| Log says the `pg` package is not installed | The Docker build did not run `npm install`; check that `package.json` contains `pg` and was pushed |
| `/api/health` says `sqlite` | `DATABASE_URL` is missing or misspelled. Data is not safe until it says `postgres` |
| Database connection error | Wrong password, or you pasted the direct string instead of the Session pooler string; copy it again from Connect |
| Site is slow on the first visit | Free Render plan was asleep; upgrade, or accept the 30 second wake-up |
| Everyone suddenly gets "Server error" | Check whether the free Supabase project was paused and resume it |
| Everyone was logged out | `SESSION_SECRET` changed; keep it fixed |
| No emails arrive | Domain not verified in Resend, wrong `MAIL_FROM`, or `BASE_URL` missing |
