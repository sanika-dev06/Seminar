# Smart College Lab Issue & Maintenance System: Complete Guide (Zero to Hero)

*Status as of 12 October 2026. Everything in the "Built" sections was checked against the real code and the automated test suite (87 checks passing). Anything I could not test myself is marked **untested** so you know exactly where the risk is.*

---

## Table of contents

0. [At a glance](#0-at-a-glance)
1. [What this project is](#1-what-this-project-is)
2. [Tech stack and why](#2-tech-stack-and-why)
3. [What is in the project folder](#3-what-is-in-the-project-folder)
4. [Zero to running (step by step)](#4-zero-to-running-step-by-step)
5. [Roles, pages and permissions](#5-roles-pages-and-permissions)
6. [Account lifecycle](#6-account-lifecycle)
7. [Complaint lifecycle](#7-complaint-lifecycle)
8. [Notifications and emails](#8-notifications-and-emails)
9. [Database](#9-database)
10. [API reference](#10-api-reference)
11. [Security: what is implemented](#11-security-what-is-implemented)
12. [Frontend details](#12-frontend-details)
13. [Configuration (all settings)](#13-configuration-all-settings)
14. [Email setup (Resend)](#14-email-setup-resend)
15. [Deploying for real](#15-deploying-for-real)
16. [Testing](#16-testing)
17. [The files you were given, and how they differ](#17-the-files-you-were-given-and-how-they-differ)
18. [What was built, in order (history)](#18-what-was-built-in-order-history)
19. [Built vs not built (status board)](#19-built-vs-not-built-status-board)
20. [Known limits and honest caveats](#20-known-limits-and-honest-caveats)
21. [Troubleshooting](#21-troubleshooting)
22. [For developers: how the code works and how to extend it](#22-for-developers-how-the-code-works-and-how-to-extend-it)
23. [Go-live checklist](#23-go-live-checklist)
24. [Rolling out to other colleges](#24-rolling-out-to-other-colleges)

---

## 0. At a glance

| Item | Value |
|---|---|
| Name | Smart College Lab Issue & Maintenance Management System |
| Purpose | Students and faculty report problems in college labs; technicians fix them; admins manage everything |
| Roles | Student, Faculty, Technician, Admin |
| Backend | Node.js 22.5+ (built-in `http`). **Zero npm dependencies** in the default SQLite mode; one optional dependency (`pg`) when you use Supabase/Postgres |
| Frontend | One HTML file (`public/index.html`) with vanilla JavaScript. No framework, no build step |
| Database | SQLite file (`lab.db`) by default, or **Supabase / Postgres** when `DATABASE_URL` is set |
| Size | `server.js` about 209 lines, `public/index.html` about 196 lines, `test.js` about 120 lines (the code is written compactly) |
| Tests | 87 automated end-to-end checks (`npm test`) |
| Branding | **Configurable per college** (logo and optional name in Settings). Ships with a neutral default logo |
| Main deliverable | `lab-fixed.zip` (the real, full-stack app) |
| Extra deliverables | `lab-standalone.html` (works by double-click, demo only), live preview link (demo only) |

---

## 1. What this project is

Colleges have labs (computer labs, ML lab, networking lab and so on). Things break: a PC will not start, a projector shows no signal, the network is down. Without a system, people tell a technician verbally or on WhatsApp, and issues get lost.

This app replaces that with one place:

1. A **student or faculty member** reports an issue (which lab, which equipment, what is wrong, how urgent, optional photo).
2. The **admin** (or a **technician** who accepts it) assigns it to a technician.
3. The **technician** works on it and updates the status (In Progress, On Hold, Resolved) with notes.
4. The **reporter** is notified at every step and can **reopen** the issue if it was not really fixed.
5. The **admin** sees everything, manages users and labs, and looks at analytics.

Every change is recorded in a history timeline, so you can always see who did what and when.

---

## 2. Tech stack and why

| Layer | Choice | Why |
|---|---|---|
| Runtime | Node.js 22.5 or newer | Includes SQLite (`node:sqlite`), so no database server and no native packages to install |
| Web server | Node built-in `http` | No Express, so nothing to install or update |
| Database | SQLite (default) or Postgres / Supabase | SQLite: zero setup, one file, plenty for one college. Postgres/Supabase: data lives outside the server (no disk needed, safe redeploys, several servers can share it) |
| Passwords | `crypto.scrypt` with a random salt | Strong, built into Node |
| Sessions | HMAC-signed cookie | Stateless, no session table |
| Frontend | Vanilla JS single page app | One file, no build tools |
| Email | Resend over HTTPS (`fetch`) | No SMTP library needed; swap provider by changing one function |
| Tests | Plain Node script | No test framework needed |
| Container | Docker (alpine) | One-command deploy on Render, Railway, Azure and similar |

**Trade-off to know:** `node:sqlite` is still marked *experimental* in Node. It works well, but its API could change in a future Node major version. `package.json` pins `engines: node >= 22.5`.

---

## 3. What is in the project folder

```
lab/
├── server.js            # entire backend: config, database, auth, rules, API routes, static files
├── public/
│   ├── index.html       # entire frontend (HTML + CSS + JS)
│   ├── logo.png         # neutral DEFAULT logo (used until a college uploads its own)
│   └── favicon.png      # default tab icon (the live icon follows the uploaded logo)
├── branding/
│   ├── JSPM-logo.png    # the JSPM logo, for JSPM's own deployment only (upload it in Settings)
│   └── README.txt
├── test.js              # 87 end-to-end checks
├── db/
│   ├── sqlite-schema.sql    # tables for SQLite mode
│   └── postgres-schema.sql  # tables for Supabase/Postgres mode (+ Row Level Security)
├── test/
│   ├── fake-pg.js           # stand-in for `pg` (backed by SQLite) so tests can run the Postgres code path
│   └── run-pg-sim.js        # `npm run test:pg`
├── package.json         # one optional dependency (pg); "start", "test", "test:pg" scripts
├── package-lock.json
├── start.bat            # Windows: double-click to run (untested on Windows)
├── start.sh             # Mac/Linux: ./start.sh
├── Dockerfile           # container image (runs as non-root user)
├── .dockerignore        # keeps .env, *.db, .git out of the image
├── render.yaml          # Render.com blueprint (one-click deploy config)
├── .github/workflows/ci.yml   # GitHub Actions: runs tests and builds the image
├── .env.example         # every setting, documented
├── .gitignore           # ignores node_modules, .env, *.db
├── README.md            # short version of this guide
└── docs/PROJECT_GUIDE.md # this file
```

Created at runtime (not in the zip): `lab.db` (database) and `.env` (your settings, created by `start.bat` / `start.sh`).

---

## 4. Zero to running (step by step)

### Level 0: Install the one requirement
Install **Node.js 22.5 or newer** from https://nodejs.org. Check with `node --version`. Older versions fail because they do not include SQLite.

### Level 1: Run it
- **Windows:** unzip `lab-fixed.zip`, double-click `start.bat`. *(untested on Windows)*
- **Mac/Linux:** unzip, open a terminal in the `lab` folder, run `./start.sh`.
- **Manual (any system):**
  ```
  cp .env.example .env      # Windows: copy .env.example .env
  npm start
  ```
Then open **http://localhost:3000** in the browser. Do not open `public/index.html` directly: the page needs the server behind it.

What the start scripts do: check your Node version, create `.env` with a random `SESSION_SECRET` if missing, start the server.

### Level 2: First-run setup (create the admin)
On a **clean database** the browser shows a one-time **setup page**. Enter name, username, email and a password of at least 8 characters. That account is the **admin**, and you are logged in. The page can never be used again once any user exists.

The app also creates the 8 default labs: Computer Vision Lab, Machine Learning Lab, Project Lab, Innovation Lab, Cybersecurity Lab, Research Lab, MAC Lab, Data Science Lab. (Admin can rename, add or change labs in **Manage Labs**.)

### Level 3: Bring in real users
1. Students, faculty and technicians click **Create an account** on the login page.
2. Their account is **pending**. They cannot log in yet and see "Your registration is awaiting admin approval."
3. The admin gets a notification, opens **Manage Users**, and clicks **Approve** (or **Reject**, which deletes the request).
4. The user can now log in.

### Level 4: Demo mode (optional, for showing the app)
Run with `DEMO=1` on an empty database to load sample data: 9 users, 8 labs, 14 complaints. Demo logins (password `demo123`): `priya061` (Student), `faculty01` (Faculty), `amit001` (Technician), `admin001` (Admin). Demo mode also enables Settings, then "Reset demo data". **Never use demo mode for real data.**

> **Common trap:** if you ran the app before in demo mode, `lab.db` already contains the demo users and the app keeps using them. To go real: stop the server, delete `lab.db`, make sure `DEMO` is not set, start again.

### Level 5: Put it online
See [section 15](#15-deploying-for-real).

---

## 5. Roles, pages and permissions

### Pages each role sees (left sidebar)

| Role | Pages |
|---|---|
| **Student** | Dashboard, Report Issue, My Complaints, Lab Information, Notifications, My Profile |
| **Faculty** | Same as Student |
| **Technician** | Dashboard, Assigned Issues, All Lab Issues, Update Status, Lab Information, Notifications, My Profile |
| **Admin** | Dashboard, Manage Users, Manage Labs, All Issues, Reports & Analytics, Settings, My Profile |

### Permission matrix

| Action | Student / Faculty | Technician | Admin |
|---|:-:|:-:|:-:|
| Report an issue | Yes | No | No |
| See own complaints | Yes | n/a | n/a |
| See all complaints | No | Yes | Yes |
| Reopen own resolved complaint (within 7 days) | Yes | No | No |
| Accept an unassigned issue | No | Yes | n/a |
| Assign issue to a technician | No | Only to self | Yes, to anyone |
| Change status | No | Yes, following the workflow | Yes, any status (override) |
| Release an issue back to the queue | No | Yes (own issues) | n/a (can unassign via dropdown) |
| Read the history of a complaint | Own complaints | All | All |
| Add / edit users, approve / reject / deactivate | No | No | Yes |
| Deactivate themselves | n/a | n/a | **No** (blocked on screen and on the server) |
| Manage labs | No | No | Yes |
| Analytics | No | No | Yes |
| Edit own profile / change password | Yes | Yes | Yes |
| Change system settings (reopen window, registration rules, test email) | No | No | Yes |

All of this is enforced **on the server**, not just hidden in the interface. Students only ever receive their own complaints from the API, and other users' emails and password hashes are never sent to the browser.

---

## 6. Account lifecycle

| Step | What happens |
|---|---|
| **First admin** | Created on the setup page (local) or from `ADMIN_USERNAME` + `ADMIN_PASSWORD` (production) |
| **Self-registration** | Student, Faculty or Technician. Fields: name, username (3-30 chars, `a-z 0-9 . _`), email, password (min 8), role, ID (RBT No. / Faculty ID / Technician ID), department. Students also give year and division. The admin can **close** registration or **limit it to college email domains** (for example only `@jspm.edu`) in Settings |
| **Pending** | Cannot log in. Hidden from other users' lists. Admins are notified |
| **Approve** | Admin clicks Approve in Manage Users. Account becomes active |
| **Reject** | Admin clicks Reject. The pending request is deleted |
| **Admin adds a user** | Manage Users, Add User. Can create any role, including extra Admins. A password (min 8 characters) is required: there is no default password. Nobody can self-register as Admin |
| **Deactivate / Activate** | Admin toggles a user. A deactivated user cannot log in, and an existing session stops working immediately |
| **Forgot password** | Login page, "Forgot password?" (only shown when email is configured). Emailed link is valid 30 minutes, works once |
| **Admin resets a password** | Admin edits the user in Manage Users and fills the optional "New password" field (min 8 characters). Works without email |
| **Change own password** | My Profile. You stay logged in; all your *other* sessions are logged out |

---

## 7. Complaint lifecycle

### 7.1 What a complaint contains
- **ID:** automatic, like `#LAB101`, `#LAB102`, ...
- **Lab** (one of the labs), **Category** (Computer, Network, Software, Projector, Electrical, Equipment, Other)
- **Equipment number** (up to 40 characters), **Title** (up to 100), **Description** (up to 2000)
- **Priority:** Low, Medium, High
- **Photo:** one optional image (png, jpg, gif or webp; about 900 KB limit after encoding; SVG is not accepted)
- **Status, assigned technician, technician remark, resolution, timestamps**

### 7.2 Status workflow

```
Pending -> Assigned -> In Progress <-> On Hold
                            |
                            v
                        Resolved  --(reporter reopens within 7 days)--> Assigned (or Pending)
```

| From | A technician can move it to | Rules |
|---|---|---|
| Pending (unassigned) | Assigned, In Progress | Accepting the issue assigns it to that technician |
| Assigned | In Progress | |
| In Progress | On Hold, Resolved | **On Hold needs a reason** (remark). **Resolved needs resolution details** and asks for confirmation |
| On Hold | In Progress | Must resume before resolving |
| Resolved | nothing | **Locked** for technicians. Only the reporter (reopen) or an admin can change it |

- The status dropdown only shows the steps that are valid at that moment, and the server enforces the same rules.
- **Admins can override any status** (to fix mistakes). Their changes are recorded in the history too.
- A technician cannot assign an issue to a different technician, and cannot touch an issue assigned to someone else.

### 7.3 Release
A technician who cannot continue (leave, wrong skill) clicks **Release this issue** and gives a reason. The issue returns to **Pending** with no technician. Admins, other technicians and the reporter are notified. The reason is saved in the history.

### 7.4 Reopen
The reporter of a **Resolved** issue sees **Not fixed? Reopen this issue** for **7 days** after resolution (the admin can change this to anything from 1 to 60 days in Settings). They must say what is still wrong. The issue goes back to **Assigned** (same technician, if still active) or **Pending**. The old resolution text is cleared (but stays in the history), so the technician must write a new one. After 7 days the button is replaced by "Please report a new issue".

### 7.5 History timeline
Every complaint window shows a **History** section: date, status, who did it, and a note (for example "Assigned to Amit Sharma", "Reason: Waiting for RAM", "Resolution: Replaced RAM", "Reopened by ...: still flickering"). Complaints created before this feature existed show "No history recorded".

---

## 8. Notifications and emails

### In-app notifications (always on)
A bell/count in the sidebar ("Notifications (2)"). Mark one or all as read. Created for: complaint submitted, assigned, status changed, **on hold (with reason)**, resolved, released, reopened, new registration waiting for approval, and new issues for technicians/admins.

### Emails (only when email is configured)
| Email | Sent to |
|---|---|
| Reset your password (link valid 30 min, single use) | The user who asked |
| Complaint assigned | The reporter, and the technician (when an admin assigns it to them) |
| Complaint resolved (includes the resolution text) | The reporter |
| Complaint reopened | The technician |

Emails are sent in the background. If the email service is down, the action still succeeds and the failure is only logged on the server.

---

## 9. Database

SQLite file `lab.db` (default) or Postgres / Supabase (`DATABASE_URL`). Seven tables, defined in `db/sqlite-schema.sql` and `db/postgres-schema.sql`:

| Table | Purpose | Key columns |
|---|---|---|
| `users` | All accounts | username (unique), password_hash, role, name, email, department, rbt_no / faculty_id / technician_id / admin_id, year, division, status (`active`, `inactive`, `pending`), profile_photo |
| `labs` | Laboratories | name (unique), description, status |
| `complaints` | Issues | complaint_id (`#LAB1xx`, unique), reported_by, lab_id, category, equipment_number, title, description, priority, status, assigned_to, technician_remark, resolution, image, created_at, updated_at, resolved_at |
| `status_history` | Timeline | complaint_id, status, by_user, note, created_at |
| `notifications` | In-app messages | user_id, complaint_id, message, is_read, created_at |
| `settings` | Admin-editable settings | key, value (`reopen_days`, `registration`, `allowed_domains`) |
| `password_resets` | Reset links | token_hash (the token itself is never stored), user_id, expires_at |

Notes: new tables are created automatically on start (`CREATE TABLE IF NOT EXISTS`), so upgrading keeps existing data. Multi-step changes run inside transactions (for example creating a complaint with its history and notifications), so a crash cannot leave half-saved data.

---

## 10. API reference

All endpoints are under `/api`, send/receive JSON, and (except the public ones) need the login cookie.

| Method | Path | Who | What it does |
|---|---|---|---|
| GET | `/health` | Public | `{status, demo, mail, setup, dev, registration, domains}`. Used by Docker and uptime monitors |
| POST | `/setup` | Public, only while no users exist | Create the first admin |
| POST | `/login` | Public | Log in (username or email, password, role). Rate limited |
| POST | `/logout` | Any | Clear the cookie |
| POST | `/register` | Public | Self-register (Student/Faculty/Technician), status pending |
| POST | `/forgot` | Public | Send a reset link by email (always answers ok) |
| POST | `/reset-password` | Public | Set a new password using the emailed token |
| GET | `/state` | Logged in | Everything the current role may see (profile, labs, users, complaints, notifications) |
| POST | `/complaints` | Student/Faculty | Report an issue |
| PATCH | `/complaints/:id` | Technician/Admin | Change status, assignment, remark, resolution (workflow rules apply) |
| POST | `/complaints/:id/release` | Technician | Return own issue to the queue (reason required) |
| POST | `/complaints/:id/reopen` | Reporter | Reopen within 7 days (reason required) |
| GET | `/complaints/:id/history` | Reporter / Technician / Admin | Timeline |
| POST | `/notifications/read` | Any | Mark one/all as read |
| PUT | `/profile` | Any | Update own name, email, photo, password |
| POST | `/users` | Admin | Add user |
| PUT | `/users/:id` | Admin | Edit user |
| POST | `/users/:id/toggle` | Admin | Activate / deactivate / approve (not yourself) |
| POST | `/users/:id/reject` | Admin | Delete a pending registration |
| PUT | `/settings` | Admin | Save reopen window (1-60 days), registration open/closed, allowed email domains |
| POST | `/settings/test-email` | Admin | Send a test email to the admin's own address (checks the email setup) |
| POST | `/labs` | Admin | Add lab |
| PUT | `/labs/:id` | Admin | Edit lab |
| POST | `/reset` | Admin, demo mode only | Reload demo data |

Standard error codes: 400 invalid input, 401 not logged in / bad credentials, 403 not allowed, 404 not found, 429 too many attempts.

---

## 11. Security: what is implemented

| Area | Detail |
|---|---|
| Passwords | scrypt with a unique salt per user; constant-time comparison |
| Sessions | HMAC-signed cookie, 8 hours; `HttpOnly`, `SameSite=Strict`, `Secure` in production |
| Session binding | The cookie includes a fingerprint of the password hash, so changing a password logs out all other sessions |
| Immediate revocation | Deactivating a user blocks them on their next request |
| Secret | `SESSION_SECRET` required in production. In dev without one, a random secret is generated at start (no weak default exists) |
| Login rate limit | 10 failed attempts per IP + username, then locked for 15 minutes (429) |
| Registration limit | 60 per IP per hour (colleges share one public IP, so it is generous), plus admin-controlled open/closed and email-domain rules |
| Forgot password | Max 30 requests per IP and 3 per email per hour; always answers "ok" (no account guessing); token 256-bit random, stored hashed, expires in 30 min, single use; wrong-token guesses are rate limited |
| Authorization | Role checks on the server for every route (RBAC); students can only fetch their own data |
| No default passwords | Admin-created accounts need an explicit password (min 8). Registration, setup, reset and the first-admin setting all require 8+ characters |
| Input validation | Length limits on every text field, image type and size check, body size cap (about 1.5 MB), username pattern, password minimum 8 |
| Headers | `Content-Security-Policy`, `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`, `Referrer-Policy: no-referrer`, HSTS in production, `Cache-Control: no-store` on API responses |
| XSS | All user text is escaped in the interface; SVG uploads not accepted; avatar initials sanitized |
| Static files | Path traversal check on `public/` |
| Demo safety | Demo data and `/api/reset` only exist with `DEMO=1` (plus `ALLOW_RESET=1` in production) |
| Docker | Runs the app as the non-root `node` user |
| Safe self-deactivation | An admin cannot deactivate their own account |

**Known security gaps** are listed in [section 20](#20-known-limits-and-honest-caveats).

---

## 12. Frontend details

- **Single file:** `public/index.html` holds the HTML, CSS and JavaScript. No framework, no build step. The app keeps its data in a global `DB` object loaded from `/api/state` and re-renders pages with plain functions.
- **Login pages:** login, **Create account**, **Forgot password**, **Reset password**, **First-time setup**. Each shows the college logo (the neutral default until the admin uploads one) and, if set, the college name; the footer shows "© year [college name] · Smart Lab Issue & Maintenance System" (plus "Developed by ..." if `DEVELOPED_BY` is set).
- **Dashboards:** stat cards per role (total, pending/assigned, in progress, on hold, resolved) and recent complaints tables.
- **Complaint window:** all details, status controls (role-aware), remark, resolution (shown only when choosing Resolved), Release / Reopen buttons, history timeline.
- **Admin screens:** Manage Users (pending approvals, add/edit/activate/deactivate), Manage Labs (with per-lab statistics), All Issues, Reports & Analytics (issues by laboratory, by category, pending vs resolved, priority distribution, average resolution time, and a 6-month trend), **Settings** (reopen window, registration open/closed + allowed email domains, email status with a "Send test email" button, architecture note, demo reset in demo mode).
- **Screen fit (laptops and large monitors):** page content is fluid and fills the screen (up to 2000 px, centered beyond that) instead of a fixed 1200 px column; dashboard stat cards are arranged in balanced rows at any width (for example 4+4 on laptops, one row on wide monitors, 2+2 on phones); Settings uses a multi-column grid on wide screens; text grows slightly on 1600 px+ and 2200 px+ displays.
- **Look and feel:** navy theme, rounded cards, status and priority tags (On Hold has a dotted outline, Low priority dashed), dark mode, responsive layout with a slide-in sidebar on phones.
- **In-app dialogs:** confirmations and reason boxes (Release, Reopen, Resolve, Reject, Reset) use the app's own dialog, because the browser's built-in `prompt()` and `confirm()` are blocked inside embedded or sandboxed frames and would make buttons look dead.
- **Branding (white-label):** the admin uploads a PNG/JPG/WebP logo (resized to 256 px in the browser, max about 400 KB, SVG refused) and an optional college name in **Settings, Branding**. It appears on every login page, the sidebar, the footer and the browser tab. It is stored in the database and served from `/brand/logo`; "Remove custom logo" restores the neutral default. No file edits are needed per college.

---

## 13. Configuration (all settings)

Settings go in `.env` (local) or in your host's environment variables (production).

| Variable | Required? | Meaning |
|---|---|---|
| `PORT` | No (3000) | Port to listen on |
| `DATABASE_URL` | No | Postgres / Supabase connection string. When set, the app uses it instead of SQLite (run `npm install` once to get `pg`). Copy it from Supabase: Connect, Session pooler. Keep it secret |
| `DB_POOL_MAX` | No (5) | Maximum database connections in Postgres mode |
| `DB_PATH` | No (`lab.db`) | SQLite file location (only used when `DATABASE_URL` is not set). In Docker use `/data/lab.db` on a persistent disk |
| `NODE_ENV` | Recommended | `production` turns on Secure cookies, HSTS, and the stricter startup checks |
| `SESSION_SECRET` | **Yes in production** | Long random string. Generate: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` |
| `ADMIN_USERNAME`, `ADMIN_PASSWORD` | **Yes in production** (first start) | Creates the first admin on an empty database. Username 3-30 chars (`a-z 0-9 . _`), password min 8. In production an empty database without these makes the server refuse to start |
| `ADMIN_NAME`, `ADMIN_EMAIL` | No | Name and email of that first admin |
| `TRUST_PROXY` | Yes behind a proxy (`1`) | Makes rate limits use the real visitor IP (Render/Railway/Azure put a proxy in front). Without it, all visitors look like one address |
| `RESEND_API_KEY`, `MAIL_FROM` | For email | Turns on forgot-password and complaint emails |
| `BASE_URL` | Required in production when email is on | Public address used inside reset links, for example `https://lab.yourcollege.edu` |
| `DEVELOPED_BY` | No | Adds "Developed by ..." to the login footer |
| `DEMO` | No | `1` loads demo data on an empty DB and enables the reset button |
| `ALLOW_RESET` | No | In production, `1` plus `DEMO=1` allows the demo reset endpoint |

---

## 14. Email setup (Resend)

1. Create an account at https://resend.com and get an **API key**.
2. Verify your sending **domain** in Resend. Until you do, Resend only delivers to your own account email, so real users will not receive anything.
3. Set `RESEND_API_KEY`, `MAIL_FROM` (an address on the verified domain, e.g. `Smart Lab <noreply@yourdomain.edu>`), and `BASE_URL`.
4. Restart. The login page now shows **Forgot password?** and complaint emails start flowing.

Without these settings in production, the Forgot-password link is hidden (admins reset passwords in Manage Users). In local development without them, the reset link is printed in the server console so you can still test the whole flow. **The actual Resend call has not been tested with a real key.** Send yourself one reset email after deploying.

---

## 15. Deploying for real

**What you need:** a host that runs a Node/Docker app with **HTTPS**, and a place to keep the data: either a **Supabase/Postgres database** (recommended, no disk needed) or, in SQLite mode, a **persistent disk**. Without one of these, data is wiped at every restart and all users disappear.

### Using Supabase (recommended)
1. In Supabase, open your project, click **Connect**, choose **Session pooler**, and copy the connection string. Put your database password into it (Project Settings, then Database, can reset it if you forgot it). The session pooler works on IPv4-only hosts such as Render and Railway.
2. Set it as `DATABASE_URL` in your host's environment settings. Never put it in the code or commit it.
3. Deploy. On start the app creates any missing tables (`db/postgres-schema.sql`, safe to re-run), turns on Row Level Security with no policies on every table so Supabase's public API cannot read your data, and creates your admin from `ADMIN_USERNAME` / `ADMIN_PASSWORD`.
4. Locally: add `DATABASE_URL` to `.env`, run `npm install` once, then `npm start`.

The app connects with its own database login. Supabase Auth, the REST API and the anon key are not used.

### Option A: Render (blueprint included)
1. Push the project to a GitHub repository (`.gitignore` already excludes `.env` and `*.db`).
2. In Render choose **New, Blueprint**, connect the repo; it reads `render.yaml` (Docker service, health check `/api/health`, `TRUST_PROXY=1`, generated `SESSION_SECRET`).
3. Fill in `DATABASE_URL` (Supabase), `ADMIN_USERNAME`, `ADMIN_PASSWORD`, `BASE_URL` (and optionally the email settings). For SQLite mode instead, leave `DATABASE_URL` empty and uncomment the disk block in `render.yaml`.
4. Deploy, open your address, log in as the admin, approve users.
Note: with Supabase you need no disk. Persistent disks (SQLite mode only) need a paid Render plan.

### Option B: Railway, Azure, any Docker host
Use the same `Dockerfile`. Set the environment variables from section 13 (with `DATABASE_URL`, or mount a volume at `/data` for SQLite), set `TRUST_PROXY=1`, and monitor `/api/health` (it also reports `db: "postgres"` or `"sqlite"`).

### Dockerfile notes
The container starts as root only to fix ownership of the mounted `/data` disk (mounted disks are often root-owned), then drops to the non-root `node` user with `su-exec`. **This Docker build has not been tested** (no Docker in my environment). If the build fails, send me the error.

### Operating it
- **Backups:** SQLite mode: copy `lab.db` regularly (best while the server is stopped). Supabase mode: use the backup options of your Supabase plan and check what your plan includes. The database holds everything, including uploaded photos.
- **Updates:** replace the code, keep `lab.db`; new tables are added automatically.
- **Monitoring:** `GET /api/health` returns `{"status":"ok"}`.
- **CI:** `.github/workflows/ci.yml` runs `npm test` and `npm run test:pg` and builds the Docker image on every push. The *deploy* step is only a comment (you choose the cloud).

---

## 16. Testing

Run `npm test`. It starts the server on a temporary SQLite database and runs **87 end-to-end checks**. `npm run test:pg` runs the **same 87 checks through the Postgres code path**, using a stand-in for the `pg` package (`test/fake-pg.js`) backed by SQLite, so no database server is needed. Both cover:

- Login: wrong password, wrong role, all roles, unauthenticated access, rate limiting after repeated failures
- Permissions: students see only their own complaints; faculty/technicians cannot use admin APIs
- Complaints: ID generation, validation, reporting by faculty
- Workflow: no skipping steps, On Hold needs a reason, resolve needs resolution, resolved is locked for technicians, technician cannot reassign to others, admin override
- Release and reopen: reasons required, only the right people, 7-day window, notifications
- History: timeline recorded, other users cannot read it
- Accounts: admin adds user, deactivation blocks login, registration (pending, duplicate, short password, Admin role rejected), approve/reject, technician registration
- Password: forgot/reset (unknown email, valid token, token reuse, old session logged out, per-email limit), own password change keeps you logged in
- Emails: assigned and resolved emails reach the right people
- Setup: first-run admin creation, locks afterwards, production refuses an empty database without admin settings
- Security: headers present, logo served

**Not covered by automated tests:** the visual interface (I tested it by hand with a headless browser: login, register, approve, report, work, resolve, reopen, release, dialogs), the Windows `start.bat`, the Docker build, real email delivery, and the 7-day-old demo data in the mock versions.

---

## 17. The files you were given, and how they differ

| File | What it is | Real accounts? | Data saved? | Needs Node? |
|---|---|---|---|---|
| **`lab-fixed.zip`** | The real full-stack app | **Yes** | **Yes**, in `lab.db` | Yes (22.5+) |
| `lab-standalone.html` | The same screens with a fake server built into the page | Fake only | In your browser only (`localStorage`) | No, just double-click |
| Live preview link | Same as standalone, hosted on claude.ai | Fake only | Resets on reload | No |

The standalone and preview versions are for **showing and trying** the interface. They cannot be shared between users, have no real security, and send no email. For anything real, use `lab-fixed.zip`.

---

## 18. What was built, in order (history)

1. **Analysis** of your original project: found security and logic problems (24 original tests, all passing).
2. **Security and bug fixes:** random session secret, login rate limit, reset endpoint locked down, security headers, SVG/avatar sanitising, atomic complaint creation, technician cannot reassign, ID validation, safer errors, Docker hardening, 29 tests.
3. **Live preview** (browser mock), later the downloadable **standalone** file.
4. **First admin from settings**, no demo data in production.
5. **Self-registration with admin approval** for Student/Faculty (later also Technician).
6. **Forgot password by email** (Resend), sessions invalidated on password change.
7. **Complaint emails** (assigned, resolved).
8. **Run scripts** (`start.bat`, `start.sh`), Render blueprint, Docker fix, README.
9. **First-run setup page**; demo mode made opt-in; technician self-registration.
10. **Branding**: logo, favicon, footer, optional "Developed by" (first hard-coded to JSPM).
11. **Status workflow overhaul:** On Hold, strict transitions, Release, Reopen, history timeline, resolve confirmation, email bug fixed (87 tests).
12. **In-app dialogs** replacing browser pop-ups that were blocked in embedded frames (fixed the "Release is not clickable" problem).

13. **Final fact-check of this guide** found and fixed one more issue: users added by an admin with a blank password silently received the password `demo123`. A password (min 8 characters) is now required, and the minimum for admin password edits was raised from 6 to 8 (87 tests).

14. **Admin Settings page:** reopen window, registration open/closed with allowed email domains, and a test-email button (87 tests). Testing in a real browser caught an element-id clash with the sidebar, and a stale "Create an account" link after logout; both fixed.

15. **White-label branding:** the JSPM logo and name were hard-coded, so the app looked like it belonged to one college. Logo and college name are now admin settings (neutral default logo shipped, JSPM logo moved to `branding/`), the browser tab icon follows the logo, and a new `/brand/logo` endpoint serves it (87 tests).

16. **Screen-fit update:** removed the 1200 px content cap (it left 30% of a 1920 px screen and half of a 2560 px screen empty), balanced the stat-card rows, made Settings use the full width. Measured at 1280, 1366, 1440, 1536, 1920 and 2560 px wide plus a phone and tablet: no horizontal overflow, content fills 100% up to 2000 px.

17. **Supabase / Postgres support:** the server's database layer was rewritten to be asynchronous (all 87 tests still pass on SQLite). When `DATABASE_URL` is set the app uses Postgres through a small connection pool; transactions hold one connection; `COUNT(*)` is parsed as a number; NaN parameters become NULL; Postgres error codes no longer crash the error handler; list queries are ordered by id. Tables were created in your Supabase project with Row Level Security on and API access revoked (advisors report only the expected "RLS enabled, no policy" notices). The Dockerfile now installs the one dependency, and the old package-lock was removed (it is regenerated by `npm install`).

Ideas you reviewed and **declined**: logo-based colour changes (red theme options), showing department name, showing the full college name.

---

## 19. Built vs not built (status board)

### Built and working (checked)
- [x] Four roles with server-enforced permissions
- [x] Real login, sessions, rate limiting, secure cookies
- [x] First-run admin setup page; production admin from settings
- [x] Self-registration (Student, Faculty, Technician) with admin approve/reject
- [x] Admin: add/edit/activate/deactivate users; manage labs; analytics; all issues
- [x] Admin Settings page: reopen window, close registration or limit it to college email domains, test-email button
- [x] Report issue with category, priority, equipment, optional photo
- [x] Full status workflow with On Hold, locking, release, reopen (7 days), history timeline
- [x] In-app notifications for every step
- [x] Emails: forgot password, assigned, resolved, reopened (when configured)
- [x] Forgot-password flow with expiring single-use links
- [x] Branding per college: logo upload, optional college name, favicon, login footer (neutral default logo; the JSPM logo is kept in `branding/`)
- [x] Dark mode and mobile-friendly layout
- [x] Docker, Render blueprint, CI (tests and image build), run scripts
- [x] 87 automated tests

- [x] Supabase / Postgres support: async database layer, `db/postgres-schema.sql`, Row Level Security, `DATABASE_URL` switch (SQLite stays the default)

### Built but **not fully verified** (needs your confirmation)
- [ ] The running app connected to your Supabase with the real `pg` driver and your `DATABASE_URL` (I could not reach the internet from my environment). What *was* verified: the tables exist in your Supabase project, all 57 SQL statements the app sends were accepted by that real Postgres, a rolled-back behaviour test passed there (integer ids, large expiry times, upserts, foreign keys, duplicate usernames, API roles locked out), and all 87 tests pass through the Postgres code path with a stand-in driver
- [ ] `start.bat` on Windows
- [ ] Docker image build and the disk-permission fix on Render
- [ ] Real email delivery with your Resend key and domain
- [ ] Render deployment end to end

### Not built yet (roadmap)

**Priority 1: useful soon**
- [ ] Safe delete / "remove user" (with last-admin protection). Today you can deactivate but not delete
- [ ] Admin audit log (who created, approved, or deactivated which user)
- [ ] CSV/PDF export of complaints and reports
- [ ] Per-user email opt-out; email for On Hold and "new issue" to admins
- [ ] Email verification at sign-up (today admin approval is the only gate)
- [ ] Real deploy step in CI (needs your chosen cloud)
- [ ] Logo in emails (needs HTML emails)

**Priority 2: scale and quality**
- [ ] Pagination: `/api/state` currently sends *all* visible data, including images, in one request. Fine for a college lab, heavy at thousands of complaints
- [ ] Split `server.js` into modules (routes, db, auth, mail); more readable code style
- [ ] Phone polish found in the screen audit: card layout instead of wide tables, bigger touch targets (links are 16 px tall, menu button 32 px), full-screen complaint window with fixed action bar, permanent sidebar on tablets (about 900 px+)
- [ ] Automated browser (UI) tests
- [x] ~~Option to use PostgreSQL instead of experimental `node:sqlite`~~ (done: Supabase/Postgres support)
- [ ] Script to copy existing SQLite data into Postgres (today a Supabase deployment starts with a fresh database)
- [ ] Accessibility review (screen readers, keyboard)
- [ ] Automatic scheduled database backups

**Priority 3: nice features**
- [ ] Multiple photos or file attachments; comments / chat thread on a complaint
- [ ] SLA timers and escalation (for example High priority unassigned for 24 hours alerts admin)
- [ ] Technician workload view and auto-assignment
- [ ] Student feedback / rating after resolution
- [ ] QR code on equipment to open a pre-filled report form
- [ ] Equipment inventory and preventive-maintenance schedule
- [ ] Date-range filters in analytics
- [ ] Hindi / Marathi language switch; installable app (PWA); push / WhatsApp / SMS alerts
- [ ] Two-factor login; "log out everywhere" session list; CAPTCHA on registration
- [ ] More Settings: edit categories/priorities, one-click database backup/export, system status panel (version, DB size, pending approvals)
- [ ] Login-page extras you listed earlier: notice board, live statistics, role hints, Caps-Lock warning, "remember me"

---

## 20. Known limits and honest caveats

1. **`node:sqlite` is experimental** (SQLite mode only). It is stable in practice but may change in a future Node version. Postgres mode does not use it.
2. **Data size:** photos are stored inside the database as text (base64). Many photos make `lab.db` large and slow `/api/state`.
3. **Rate limits live in memory.** In SQLite mode you must run a single instance. With Postgres several instances can share the data, but each keeps its own rate-limit counters. Restarting a server clears its counters (login lock-outs reset).
4. **Pending registration can be abused for spam** (rate limited to 60 per IP per hour; the admin can limit sign-ups to college email domains, but nothing verifies the email address belongs to the person).
5. **Anyone can request a password reset** for any email; they only receive mail if the account exists, and nothing is revealed on screen.
6. **No audit trail for admin actions** and no way to delete users (yet).
7. **Technician IDs shown in the interface** (like TECH001) are separate from usernames; this is only a label.
8. **Mock versions (standalone/preview)** store passwords unencrypted in your browser. They are for demos only.
9. **Reopen window** defaults to 7 days and can be changed in Settings (1 to 60 days).
10. **The College name and department** are intentionally not shown (your decision).
11. **Colour theme** stays navy (the red-themed options were declined).
12. **Resend free tier** limits how many emails you can send per day/month, and needs a verified domain for real recipients.

---

## 21. Troubleshooting

| Symptom | Likely cause and fix |
|---|---|
| Login page does nothing / "network error" | Server not running, or you opened the HTML file directly. Run `start.bat` / `./start.sh` and use `http://localhost:3000` |
| "Invalid username or password" | Role dropdown does not match the account, or wrong password |
| "Too many failed attempts" | Rate limit. Wait 15 minutes or restart the server |
| Server exits at start, mentions Node version | Install Node 22.5+ |
| Server exits: "SESSION_SECRET is required" | You set `NODE_ENV=production` without `SESSION_SECRET` |
| Server exits: "Empty database: set ADMIN_USERNAME..." | Production mode with a new database needs `ADMIN_USERNAME` and `ADMIN_PASSWORD` |
| I still see demo accounts | `lab.db` contains demo data or `DEMO=1` is set. Delete `lab.db`, unset `DEMO` |
| I log in but get thrown back to login | Cookie rejected. In production use HTTPS; do not use a plain `http://192.168...` address |
| Forgot-password link missing | Email not configured (`RESEND_API_KEY`, `MAIL_FROM`, `BASE_URL`) |
| Reset email never arrives | Domain not verified in Resend, wrong `MAIL_FROM`, or check spam; look at server logs |
| All users vanish after redeploy | No persistent disk at `/data` |
| Everyone gets rate-limited together | Missing `TRUST_PROXY=1` behind a proxy |
| No Deactivate button on my own row | By design: you cannot deactivate yourself. Create another admin first |
| Release / Reopen / Resolve buttons seem dead | Old version using browser pop-ups inside an embedded frame. Use the latest files (in-app dialogs) and hard-refresh (Ctrl+F5) |
| Technician cannot pick "Resolved" | The issue must be In Progress first (workflow). On Hold must resume first |

---

## 22. For developers: how the code works and how to extend it

### Backend (`server.js`) in reading order
1. **Config:** reads `.env`, defines `PROD`, `DEMO`, secrets, mail settings.
2. **Database:** chooses SQLite or Postgres, creates tables, and provides small async helpers `one()`, `all()`, `run()`, `ins()` and `tx()` (transactions; in Postgres a transaction holds one pooled connection). All database calls are `await`ed, so the server never blocks while Postgres answers. Start-up work (tables, first admin) finishes before the first request is served (`ready`).
3. **Auth helpers:** `hash/verify` (scrypt), `mkToken/readToken` (signed cookie bound to the password fingerprint), rate limiter (`limited`, `badTry`, `hit`).
4. **Startup:** if the database is empty, create the first admin (production or `ADMIN_USERNAME`), seed demo data (`DEMO=1`), or leave it for the setup page.
5. **Domain functions:** `createComplaint`, `updateComplaint` (workflow rules `TR`), `releaseComplaint`, `reopenComplaint`, `register`, `forgot`, `resetPassword`, `setup`, user/lab save functions, `state(u)`.
6. **Routes:** one array of `[method, regex, handler, requiresAuth]`. Handler signature: `async (req, user, body, match, res) => result`. Errors are thrown with `fail(status, message)`.
7. **HTTP server:** security headers, JSON body parsing with a size limit, route matching, static files from `public/`.

### Frontend (`public/index.html`)
- Globals: `DB` (server data), `me` (current user), `page`, view flags (`REGMODE`, `AUTHVIEW`, `SETUP`).
- `req(method, url, body)` wraps `fetch` and throws the server's error message.
- `render()` draws the login views or the shell (`shell()`) plus the current page (`guard()` chooses the page function).
- Page functions: `dash`, `list`, `table`, `detail`, `report`, `users`, `manageLabs`, `analytics`, `settings`, ...
- `dlg()` is the reusable in-app dialog (title, message, optional reason box).

### Example: add a new complaint category
Edit `CATS` in both `server.js` and `public/index.html`.

### Example: add a new API feature
1. Write a function in `server.js` that validates input, checks the role with `need(u, 'Role')`, writes to the database (inside `tx()` if it changes several rows) and returns data.
2. Add a route entry to the routes array.
3. Add a button or page in `index.html` that calls `req(...)`, then `await refresh(); render()`.
4. Add checks to `test.js`.

### Change the reopen window or session length
The reopen window is an admin setting (Settings page). The session length is the cookie `Max-Age=28800` (8 hours) in `server.js`.

---

## 23. Go-live checklist

- [ ] Node 22.5+ (local) or the Docker image (hosted)
- [ ] `NODE_ENV=production`
- [ ] `SESSION_SECRET` set to a long random value
- [ ] `ADMIN_USERNAME` and a strong `ADMIN_PASSWORD` set (change the password in My Profile after first login, and remove `ADMIN_PASSWORD` from the settings if you like)
- [ ] `DEMO` **not** set; no `lab.db` left over from demo runs
- [ ] HTTPS address, `BASE_URL` set to it
- [ ] `TRUST_PROXY=1` if behind a proxy
- [ ] Persistent disk mounted at `/data`, `DB_PATH=/data/lab.db`
- [ ] Email: `RESEND_API_KEY`, `MAIL_FROM` (verified domain); test one reset email
- [ ] Log in as admin, create or approve users, check each role's pages
- [ ] Report a test issue and walk it through: assign, In Progress, On Hold, Resolved, Reopen
- [ ] Backup plan for `lab.db`
- [ ] Upload your college's logo in Settings, Branding (only a logo you have the right to use; the JSPM logo carries a registered mark, so get permission before using it publicly)

---

## 24. Rolling out to other colleges

The app is now **branding-neutral**: each college's admin sets its own logo and name. Choose how to host many colleges:

| | **Option A: one copy per college** (start here) | **Option B: one shared app (multi-tenant)** |
|---|---|---|
| How | Each college gets its own deployment, database and address | One deployment; every table gets a `college_id`; PostgreSQL |
| Code change | Almost none (already works) | Large: tenant filtering on every query, super-admin role, onboarding |
| Risk | Low; colleges are isolated | A single missed filter can leak data between colleges |
| Updates | Roll out to each copy | Update once |
| Best for | First 3 to 10 colleges | Many colleges, real product |

**Recommended path:** (1) pilot with 2 or 3 colleges using Option A, (2) add the audit log, safe user deletion, export and automated backups they will ask for, (3) only then build Option B.

**Not built for multi-college yet:** a super-admin who creates and suspends colleges, per-college username/complaint-ID namespaces, college sign-up and verification, billing, a privacy policy and terms (and a check of India's DPDP Act duties), and a per-college email sender.
