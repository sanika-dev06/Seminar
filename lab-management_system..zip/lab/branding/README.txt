Branding folder (local use)

The app does not read this folder. Upload your college logo inside the app: log in as admin, Settings -> Branding.

The JSPM logo (branding/JSPM-logo.png) is a registered mark. It is kept out of Git on purpose (see .gitignore),
so it never ends up in a public repository.
