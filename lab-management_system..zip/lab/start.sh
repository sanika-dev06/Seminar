#!/bin/sh
# One-command start (Mac/Linux): checks Node, creates .env with a random secret, starts the server.
cd "$(dirname "$0")"
node -e "const[a,b]=process.versions.node.split('.').map(Number);process.exit(a>22||(a===22&&b>=5)?0:1)" 2>/dev/null || { echo "Node.js 22.5 or newer is required (found: $(node -v 2>/dev/null || echo none)). Install from https://nodejs.org"; exit 1; }
[ -f .env ] || printf 'PORT=3000\nSESSION_SECRET=%s\nDB_PATH=lab.db\nNODE_ENV=development\n' "$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")" > .env
echo "Starting... open http://localhost:3000"
exec npm start
