# Smart College Lab Issue & Maintenance Management System
Full-stack app: **Node.js ≥ 22.5** (http + built-in SQLite, zero dependencies by default) backend, vanilla-JS frontend in `public/`. Optionally uses **Supabase / Postgres** instead of SQLite (one optional dependency, `pg`).

## Run locally
Easiest: Windows -> double-click `start.bat` · Mac/Linux -> `./start.sh` (needs Node.js 22.5+; creates `.env` for you and starts the server).
Manual:
    cp .env.example .env      # set SESSION_SECRET
    npm start                 # http://localhost:3000  (first visit shows a setup page to create the admin)
    npm test                  # 87 end-to-end auth / RBAC / workflow / rate-limit checks

## How people get accounts (real use)
1. **First run:** open the site; an empty database shows a one-time setup page where you create the **admin** account. (In production, set `ADMIN_USERNAME` + `ADMIN_PASSWORD` instead.)
2. **Everyone else registers themselves** on the login page as **Student, Faculty or Technician** (name, username, email, password, ID).
3. Their account stays *pending* until the admin approves it in **Manage Users** (admins are notified). Rejecting deletes the request.
4. Extra admins are created by an existing admin in Manage Users. Nobody can self-register as Admin.

### Demo mode (optional)
`DEMO=1 npm start` on an empty database loads sample users, labs and complaints (password `demo123`: `priya061`, `faculty01`, `amit001`, `admin001`) and enables the Settings → "Reset demo data" button. Do not use demo mode for real data.

## Architecture
User → Web app (`public/index.html`) → REST API (`server.js`) → SQLite or Postgres/Supabase (`users, labs, complaints, status_history, notifications, settings, password_resets`) → Cloud deployment.
Passwords: scrypt + salt. Login is rate-limited (10 failures / 15 min per IP+username). CSP, HSTS (prod) and other security headers are set. Sessions: signed HttpOnly SameSite cookie (8 h). Every route enforces role checks server-side; students/faculty only receive their own complaints.

## API summary
POST /api/login · /api/logout · GET /api/state · POST /api/complaints · PATCH /api/complaints/:id · POST /api/notifications/read · PUT /api/profile · Admin: /api/users (POST, PUT /:id, POST /:id/toggle), /api/labs (POST, PUT /:id), POST /api/reset · GET /api/health

## Deploy
Docker: `docker build -t smart-lab . && docker run -p 3000:3000 -e SESSION_SECRET=... -v labdata:/data smart-lab`.
On Render/Railway/Azure: use the Dockerfile, attach a persistent disk at `/data`, set `SESSION_SECRET`. CI in `.github/workflows/ci.yml`.
For a managed cloud DB (Postgres), replace the small `db` helper layer in `server.js`.

## Production notes
- **First admin:** on an empty database in production, set `ADMIN_USERNAME` + `ADMIN_PASSWORD` (min 8 chars; optional `ADMIN_NAME`, `ADMIN_EMAIL`). Only that admin and the lab list are created, with no demo accounts or demo complaints. Locally, setting `ADMIN_USERNAME` does the same instead of the demo seed.
- **Registration:** students/faculty can self-register on the login page. New accounts are `pending` until an admin approves (or rejects) them in **Manage Users**; admins get a notification. Registration is limited to 60 per IP per hour; admins can close registration or limit it to college email domains in Settings.
- **Forgot password:** set `RESEND_API_KEY`, `MAIL_FROM` and `BASE_URL`. The login page then shows "Forgot password?"; the emailed link (30 min, single use, token stored hashed) opens a set-new-password page. It always answers "ok" so accounts can't be probed, and is limited per email (3/h) and per IP (30/h). Without mail config in production the link is hidden and admins reset passwords in Manage Users. In dev the link is printed to the server console.
- **Complaint emails:** when mail is configured, the reporter is emailed when their complaint is assigned and when it is resolved (with the resolution text), and a technician is emailed when an admin assigns an issue to them. In-app notifications are unchanged.
- Changing a password (reset, profile, or by an admin) logs out all other sessions of that user.
- `SESSION_SECRET` is mandatory in production (a random per-start secret is used in dev only).
- Set `TRUST_PROXY=1` when running behind a reverse proxy so rate limits see the real client IP.
- Demo data and `POST /api/reset` exist only when `DEMO=1` (and, in production, `ALLOW_RESET=1`).
- The container runs as the non-root `node` user; mount a persistent `/data` volume writable by it and back up `lab.db`.

## Branding
Set `DEVELOPED_BY` (optional) in `.env` to add a "Developed by ..." line to the login-page footer. The app ships with a neutral default logo. Each college's admin uploads its own logo and optional name in **Settings, Branding** (shown on login pages, sidebar, footer and browser tab), so no file edits are needed. The JSPM logo is a registered mark and is not part of this repository; upload your own college's logo in Settings, Branding.

## Complaint status workflow
`Pending -> Assigned -> In Progress <-> On Hold -> Resolved`. Technicians only see the next valid steps (no skipping; **On Hold** needs a reason; **Resolved** needs resolution details and is locked afterwards). A technician can **Release** an issue back to the queue (reason required). The reporter can **Reopen** a resolved issue within 7 days (reason required). Admins can override any status. Every change is stored in `status_history` and shown as a timeline in the complaint window.

## Database: SQLite (default) or Supabase / Postgres
- **Default:** a local SQLite file (`lab.db`). Nothing to install.
- **Supabase / Postgres:** set `DATABASE_URL` and run `npm install` once (installs `pg`). The app then stores everything in Postgres, so no persistent disk is needed on the host and several servers can share one database.
  1. Supabase dashboard, **Connect**, **Session pooler**: copy the connection string and put your database password in it (the session pooler also works on IPv4-only hosts such as Render).
  2. Set it as `DATABASE_URL` (in `.env` locally, or in your host's environment settings). Never commit it.
  3. Start the app. It creates the tables if they are missing (`db/postgres-schema.sql`, safe to re-run), enables Row Level Security with no policies on every table so Supabase's public API cannot read them, and the first-run setup / `ADMIN_USERNAME` flow creates your admin.
- The same schema is in `db/postgres-schema.sql` if you prefer to run it in the Supabase SQL editor yourself.
- `npm test` runs the 87 checks on SQLite. `npm run test:pg` runs the same 87 checks through the Postgres code path using a stand-in for `pg` (no database server needed).
- There is no automatic copy of existing SQLite data into Postgres yet; start a Supabase deployment with a fresh database.

## Deploying
Step-by-step from zero (GitHub, Supabase, Render, automatic updates on every push): see `docs/DEPLOY_GUIDE.md`.
