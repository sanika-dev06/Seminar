// Runs the whole test-suite through the app's Postgres code path using the SQLite-backed stand-in for "pg".
process.env.DATABASE_URL='postgres://fake:fake@localhost:5432/fake';
process.env.PG_MODULE=require('path').join(__dirname,'fake-pg.js');
require('../test.js');
