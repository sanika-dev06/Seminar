@echo off
rem One-click start (Windows): checks Node, creates .env with a random secret, starts the server.
cd /d "%~dp0"
node -e "const[a,b]=process.versions.node.split('.').map(Number);process.exit(a>22||(a===22&&b>=5)?0:1)" 2>nul || (echo Node.js 22.5 or newer is required. Install from https://nodejs.org & pause & exit /b 1)
if not exist .env (
  for /f "usebackq delims=" %%i in (`node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`) do (
    (echo PORT=3000& echo SESSION_SECRET=%%i& echo DB_PATH=lab.db& echo NODE_ENV=development)> .env
  )
)
echo Starting... opening http://localhost:3000
start "" http://localhost:3000
npm start
pause
