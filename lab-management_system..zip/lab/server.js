// Smart Lab Maintenance — zero-dependency Node.js backend (Node >= 22.5: built-in SQLite, crypto, http)
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto'),{AsyncLocalStorage}=require('async_hooks');
try{for(const l of fs.readFileSync(path.join(__dirname,'.env'),'utf8').split('\n')){const m=l.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/);if(m&&!(m[1] in process.env))process.env[m[1]]=m[2]}}catch{}
const PORT=+process.env.PORT||3000,PROD=process.env.NODE_ENV==='production',SECRET=process.env.SESSION_SECRET||crypto.randomBytes(32).toString('hex'); // no weak default: without SESSION_SECRET a random one is used (sessions reset on restart)
if(PROD&&!process.env.SESSION_SECRET){console.error('SESSION_SECRET is required in production');process.exit(1)}
if(!PROD&&!process.env.SESSION_SECRET)console.warn('WARNING: SESSION_SECRET not set - using a random one, sessions reset on restart.');
const DEV=(process.env.DEVELOPED_BY||'').trim().slice(0,120);
const DEMO=process.env.DEMO==='1',ALLOW_RESET=DEMO&&(!PROD||process.env.ALLOW_RESET==='1'); // demo data/reset only when DEMO=1
// ---- database: SQLite (default) or Postgres / Supabase when DATABASE_URL is set ----
const DATABASE_URL=(process.env.DATABASE_URL||'').trim(),PG=!!DATABASE_URL,txStore=new AsyncLocalStorage();
let db=null,pool=null; // db = raw SQLite handle (SQLite mode), pool = pg Pool (Postgres mode)
if(PG){let pg;try{pg=require(process.env.PG_MODULE||'pg')}catch{console.error('DATABASE_URL is set but the "pg" package is not installed. Run: npm install');process.exit(1)}pg.types.setTypeParser(20,v=>parseInt(v,10)); // COUNT(*) is bigint: return a number, not a string
 pool=new pg.Pool({connectionString:DATABASE_URL,max:+process.env.DB_POOL_MAX||5,ssl:/localhost|127\.0\.0\.1|sslmode=disable/.test(DATABASE_URL)?false:{rejectUnauthorized:false}});
 pool.on('error',e=>console.error('Database pool error:',e.message))}
else{const{DatabaseSync}=require('node:sqlite');db=new DatabaseSync(process.env.DB_PATH||path.join(__dirname,'lab.db'));db.exec('PRAGMA foreign_keys=ON')}
const toPg=s=>{let i=0;return s.replace(/\?/g,()=>'$'+(++i))},pgParam=v=>typeof v==='number'&&Number.isNaN(v)?null:v;
const q=async(s,p=[])=>{if(PG){const r=await(txStore.getStore()||pool).query(toPg(s),p.map(pgParam));return r.rows}
 const st=db.prepare(s);if(/^\s*(SELECT|WITH)/i.test(s)||/\bRETURNING\b/i.test(s))return st.all(...p);st.run(...p);return[]};
const LABS=["Computer Vision Lab","Machine Learning Lab","Project Lab","Innovation Lab","Cybersecurity Lab","Research Lab","MAC Lab","Data Science Lab"];
const CATS=["Computer","Network","Software","Projector","Electrical","Equipment","Other"],PRI=["Low","Medium","High"],STS=["Pending","Assigned","In Progress","On Hold","Resolved"],ROLES=["Student","Faculty","Technician","Admin"];
const LABD=["Image processing & CV research","ML model training workstations","Final-year project work","Prototyping & hackathons","Security & ethical hacking","Faculty and PG research","Apple Mac workstations","Data analytics & big data"];
const IDF={Student:'rbt_no',Faculty:'faculty_id',Technician:'technician_id',Admin:'admin_id'};
const initSchema=()=>PG?pool.query(fs.readFileSync(path.join(__dirname,'db','postgres-schema.sql'),'utf8')):db.exec(fs.readFileSync(path.join(__dirname,'db','sqlite-schema.sql'),'utf8'));
const all=(s,...p)=>q(s,p),one=async(s,...p)=>(await q(s,p))[0],run=async(s,...p)=>{await q(s,p)};
const ins=async(t,o)=>{const k=Object.keys(o);return(await q(`INSERT INTO ${t}(${k})VALUES(${k.map(()=>'?')}) RETURNING id`,k.map(x=>o[x]??null)))[0].id};
const MAIL_KEY=process.env.RESEND_API_KEY,MAIL_FROM=process.env.MAIL_FROM,BASE=(process.env.BASE_URL||`http://localhost:${PORT}`).replace(/\/$/,'');
if(PROD&&MAIL_KEY&&!process.env.BASE_URL){console.error('BASE_URL (e.g. https://lab.yourcollege.edu) is required when email is configured in production');process.exit(1)}
const mailer={enabled:()=>!!(MAIL_KEY&&MAIL_FROM)||!PROD,
 async send(to,subject,text){if(!(MAIL_KEY&&MAIL_FROM)){if(process.env.NODE_ENV!=='test')console.log(`[dev mail] To: ${to}\nSubject: ${subject}\n${text}\n`);return}
  const r=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+MAIL_KEY,'Content-Type':'application/json'},body:JSON.stringify({from:MAIL_FROM,to:[to],subject,text})});if(!r.ok)throw new Error('mail provider returned '+r.status)}};
const emailUser=async(uid,subject,text)=>{const r=await one('SELECT name,email FROM users WHERE id=?',uid);if(r&&r.email&&mailer.enabled())mailer.send(r.email,subject,`Hi ${r.name},\n\n${text}\n\n- Smart Lab Maintenance`).catch(e=>console.error('Email failed:',e.message))};
const HITS=new Map(),hit=(k,max)=>{const r=HITS.get(k);if(r&&r.t>Date.now()){if(r.n>=max)return false;r.n++;return true}if(HITS.size>5000)HITS.clear();HITS.set(k,{n:1,t:Date.now()+36e5});return true};
const ipOf=req=>process.env.TRUST_PROXY==='1'?(String(req.headers['x-forwarded-for']||'').split(',').pop().trim()||req.socket.remoteAddress):req.socket.remoteAddress;
const REG=new Map();
const tx=async f=>{if(!PG){db.exec('BEGIN');try{const r=await f();db.exec('COMMIT');return r}catch(e){try{db.exec('ROLLBACK')}catch{}throw e}}
 const c=await pool.connect();try{await c.query('BEGIN');const r=await txStore.run(c,f);await c.query('COMMIT');return r}catch(e){try{await c.query('ROLLBACK')}catch{}throw e}finally{c.release()}};
const FAILS=new Map(),MAXF=10,WIN=15*60e3;
const limited=k=>{const r=FAILS.get(k);return!!r&&r.t>Date.now()&&r.n>=MAXF};
const badTry=k=>{if(FAILS.size>5000)for(const[a,v]of FAILS)if(v.t<=Date.now())FAILS.delete(a);const r=FAILS.get(k);if(r&&r.t>Date.now())r.n++;else FAILS.set(k,{n:1,t:Date.now()+WIN})};
const now=()=>new Date().toISOString(),ago=d=>new Date(Date.now()-d*864e5).toISOString();
/* ---- passwords & sessions ---- */
const hash=p=>{const s=crypto.randomBytes(16).toString('hex');return s+':'+crypto.scryptSync(p,s,32).toString('hex')};
const verify=(p,h)=>{const[s,k]=h.split(':');const a=crypto.scryptSync(p,s,32),b=Buffer.from(k,'hex');return a.length===b.length&&crypto.timingSafeEqual(a,b)};
const sign=v=>crypto.createHmac('sha256',SECRET).update(v).digest('hex');
const fp=h=>crypto.createHash('sha256').update(h).digest('hex').slice(0,12),sha=t=>crypto.createHash('sha256').update(t).digest('hex');
const mkToken=u=>{const v=u.id+'.'+(Date.now()+8*36e5)+'.'+fp(u.password_hash);return v+'.'+sign(v)};
const cookie=u=>`sid=${mkToken(u)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800${PROD?'; Secure':''}`;
const readToken=async req=>{const m=(req.headers.cookie||'').match(/(?:^|;\s*)sid=([^;]+)/);if(!m)return null;const[u,e,f,s]=m[1].split('.');
 if(!s||!f)return null;const a=Buffer.from(sign(u+'.'+e+'.'+f)),c=Buffer.from(s);if(a.length!==c.length||!crypto.timingSafeEqual(a,c)||+e<Date.now())return null;
 const x=await one('SELECT * FROM users WHERE id=? AND status=?',+u,'active');return x&&fp(x.password_hash)===f?x:null};
const avatar=n=>{const i=n.split(' ').map(w=>w[0]||'').slice(0,2).join('').replace(/[^\p{L}\p{N}]/gu,'');return'data:image/svg+xml,'+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120"><rect width="120" height="120" fill="#c7d2fe"/><circle cx="60" cy="46" r="22" fill="#1E3A8A"/><ellipse cx="60" cy="112" rx="38" ry="30" fill="#1E3A8A"/><text x="60" y="52" font-size="20" text-anchor="middle" fill="#fff" font-family="sans-serif">${i}</text></svg>`)};
/* ---- seed ---- */
async function seed(){if(PG)await run('TRUNCATE status_history,notifications,complaints,labs,users RESTART IDENTITY CASCADE');else for(const t of['status_history','notifications','complaints','labs','users']){await run(`DELETE FROM ${t}`);await run('DELETE FROM sqlite_sequence WHERE name=?',t)}
 const U=(username,role,name,department,x={})=>ins('users',{username,password_hash:hash('demo123'),role,name,email:x.email||username+'@example.com',profile_photo:avatar(name),department,status:'active',created_at:ago(200),...x,email:x.email||username+'@example.com'});
 await U('priya061','Student','Priya Deshmukh','CSE',{email:'priya@example.com',rbt_no:'RBT25CS061',year:'2nd Year',division:'A'});await U('rohan062','Student','Rohan Patil','CSE',{rbt_no:'RBT25CS062',year:'2nd Year',division:'A'});
 await U('sneha063','Student','Sneha Kulkarni','IT',{rbt_no:'RBT25IT063',year:'3rd Year',division:'B'});await U('kunal064','Student','Kunal Mehta','AIML',{rbt_no:'RBT25AI064',year:'1st Year',division:'C'});
 await U('faculty01','Faculty','Dr. Meera Joshi','CSE',{faculty_id:'FAC101'});await U('faculty02','Faculty','Prof. Anil Rao','IT',{faculty_id:'FAC102'});
 await U('amit001','Technician','Amit Sharma','Lab Maintenance',{email:'amit@example.com',technician_id:'TECH001'});await U('tech002','Technician','Sunil Patil','Lab Maintenance',{technician_id:'TECH002'});
 await U('admin001','Admin','Rajesh Kulkarni','Laboratory Management',{email:'admin@example.com',admin_id:'ADM001'});
 for(const[i,n]of LABS.entries())await ins('labs',{name:n,description:LABD[i],status:'Operational',created_at:ago(300)});
 const T=[[1,1,0,'Computer','PC-15','PC not starting','Machine does not power on.','High','In Progress',7,'Checking power supply and system hardware.',''],[1,5,1,'Projector','PROJ-1','Projector shows no signal','HDMI input not detected.','Medium','Pending',0],
 [1,2,2,'Network','SW-2','Wi-Fi very slow','Lab network drops repeatedly.','High','Assigned',8],[3,1,3,'Software','PC-07','Python not installed','Python missing on this PC.','Low','Resolved',7,'Reinstalled Python 3.12.','Installed Python 3.12 and verified.'],
 [5,3,4,'Electrical','Board-3','Socket sparking','Socket sparks when plugged.','High','In Progress',8,'Isolating circuit.'],[2,4,5,'Equipment','GPU-2','GPU fan noisy','Loud noise from GPU server.','Medium','Pending',0],
 [8,2,10,'Software','PC-21','Jupyter kernel crashes','Kernel dies on start.','Medium','Resolved',7,'Environment corrupt.','Recreated conda environment.'],[4,6,15,'Computer','PC-03','Keyboard not working','Keys unresponsive.','Low','Resolved',8,'','Replaced keyboard.'],
 [6,4,30,'Network','AP-1','No internet in Research Lab','LAN port dead.','High','Resolved',7,'','Replaced patch cable.'],[7,5,45,'Projector','PROJ-3','Projector lamp dim','Image too dark.','Medium','Resolved',8,'','Lamp replaced.'],
 [1,3,60,'Software','PC-11','OpenCV import error','cv2 not found.','Medium','Resolved',7,'','Reinstalled OpenCV.'],[3,1,80,'Equipment','Mouse-9','Mouse broken','Scroll wheel broken.','Low','Resolved',8,'','New mouse issued.'],
 [2,1,110,'Electrical','UPS-1','UPS beeping','UPS alarm continuous.','High','Resolved',7,'','Battery replaced.'],[4,2,3,'Computer','PC-30','Blue screen on boot','BSOD at startup.','High','Pending',0]];
 for(const t of T){const id=await ins('complaints',{reported_by:t[1],reported_by_role:(await one('SELECT role FROM users WHERE id=?',t[1])).role,lab_id:t[0],category:t[3],equipment_number:t[4],title:t[5],description:t[6],priority:t[7],status:t[8],assigned_to:t[9]||null,technician_remark:t[10]||'',resolution:t[11]||'',created_at:ago(t[2]),updated_at:ago(t[2]),resolved_at:t[8]==='Resolved'?ago(Math.max(0,t[2]-1)):null});await run('UPDATE complaints SET complaint_id=? WHERE id=?','#LAB'+(100+id),id)}
 const N=(u,c,m)=>ins('notifications',{user_id:u,complaint_id:c,message:m,is_read:0,created_at:now()});
 await N(1,'#LAB101','Complaint #LAB101 has been assigned to Amit Sharma.');await N(1,'#LAB101','Complaint #LAB101 is now In Progress.');await N(7,'#LAB102','New Medium-priority issue #LAB102 in Computer Vision Lab.')}
const ADM_U=(process.env.ADMIN_USERNAME||'').trim().toLowerCase(),ADM_P=process.env.ADMIN_PASSWORD||'';
const noUsers=async()=>!(await one('SELECT COUNT(*) c FROM users')).c;
const addLabs=async()=>{if(!(await one('SELECT COUNT(*) c FROM labs')).c)for(const[i,n]of LABS.entries())await ins('labs',{name:n,description:LABD[i],status:'Operational',created_at:now()})};
const createAdmin=async(name,un,email,pw)=>{await addLabs();await ins('users',{username:un,password_hash:hash(pw),role:'Admin',name,email,profile_photo:avatar(name),department:'Laboratory Management',admin_id:'ADM001',status:'active',created_at:now()})};
async function firstAdmin(){if(!/^[a-z0-9._]{3,30}$/.test(ADM_U)||ADM_P.length<8){console.error('Empty database: set ADMIN_USERNAME (3-30 chars: a-z 0-9 . _) and ADMIN_PASSWORD (min 8 chars) to create the first admin.');process.exit(1)}
 await createAdmin((process.env.ADMIN_NAME||'Administrator').slice(0,80),ADM_U,process.env.ADMIN_EMAIL||ADM_U+'@example.com',ADM_P);console.log('Created first admin account: '+ADM_U)}
// empty DB: ADMIN_USERNAME set or production -> create that admin only; DEMO=1 -> demo seed; otherwise the browser shows a first-run setup page
// start-up work (schema + first admin / demo data); requests wait for it via `ready`
const ready=(async()=>{await initSchema();if(await noUsers()){if(ADM_U||PROD)await tx(firstAdmin);else if(DEMO)await tx(seed);else await tx(addLabs)}})();
ready.catch(e=>{console.error('Database start-up failed:',e.message);process.exit(1)});
/* ---- domain logic ---- */
const fail=(c,m)=>Object.assign(new Error(m),{code:c}),FORBID='You do not have permission to access this page.';
const notify=(uid,cid,msg)=>ins('notifications',{user_id:uid,complaint_id:cid,message:msg,is_read:0,created_at:now()});
const pub=u=>({id:u.id,name:u.name,role:u.role,department:u.department,rbt_no:u.rbt_no,faculty_id:u.faculty_id,technician_id:u.technician_id,admin_id:u.admin_id});
const full=u=>{const{password_hash,...r}=u;return r};
// admin-editable settings (stored in the DB)
const getSet=async(k,d)=>{const r=await one('SELECT value FROM settings WHERE key=?',k);return r?r.value:d};
const setSet=(k,v)=>run('INSERT INTO settings(key,value)VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',k,String(v));
const setMap=async()=>{const m={};for(const r of await all("SELECT key,CASE WHEN key='logo' THEN CASE WHEN value<>'' THEN '1' ELSE '' END ELSE value END AS value FROM settings"))m[r.key]=r.value;return m};
const gs=(m,k,d)=>k in m?m[k]:d;
const reopenDays=m=>Math.min(60,Math.max(1,parseInt(gs(m,'reopen_days','7'),10)||7));
const regDomains=m=>gs(m,'allowed_domains','').split(',').map(x=>x.trim().toLowerCase().replace(/^@/,'')).filter(Boolean);
const brand=m=>({college_name:gs(m,'college_name',''),logo_v:parseInt(gs(m,'logo_v','0'),10)||0});
const LOGO_RE=/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/,LOGO_MAX=600000;
const logoOk=(d)=>{const m=LOGO_RE.exec(d||'');if(!m||d.length>LOGO_MAX)return false;const b=Buffer.from(m[2],'base64');if(b.length<8)return false;
 return m[1]==='image/png'?b.subarray(0,4).toString('hex')==='89504e47':m[1]==='image/jpeg'?b.subarray(0,3).toString('hex')==='ffd8ff':b.subarray(0,4).toString()==='RIFF'&&b.subarray(8,12).toString()==='WEBP'};
const settingsView=m=>({reopen_days:reopenDays(m),registration:gs(m,'registration','open'),allowed_domains:regDomains(m).join(', '),college_name:gs(m,'college_name',''),has_logo:!!gs(m,'logo','')});
const state=async u=>{const m=await setMap(),adm=u.role==='Admin',own=['Student','Faculty'].includes(u.role);
 const[labs,users,complaints,notifications]=await Promise.all([await all('SELECT * FROM labs ORDER BY id'),adm?await all('SELECT * FROM users ORDER BY id'):await all("SELECT * FROM users WHERE status<>'pending' OR id=? ORDER BY id",u.id),
  own?await all('SELECT * FROM complaints WHERE reported_by=? ORDER BY id',u.id):await all('SELECT * FROM complaints ORDER BY id'),await all('SELECT * FROM notifications WHERE user_id=? ORDER BY id',u.id)]);
 return{settings:adm?{...settingsView(m),mail:mailer.enabled(),mail_real:!!(MAIL_KEY&&MAIL_FROM)}:{reopen_days:reopenDays(m)},me:full(u),labs,users:adm?users.map(full):users.map(x=>x.id===u.id?full(x):pub(x)),complaints,notifications}};
const str=(v,max,name)=>{v=String(v??'').trim();if(v.length>max)throw fail(400,`${name} is too long.`);return v};
const img=v=>{if(!v)return null;if(typeof v!=='string'||!/^data:image\/(png|jpe?g|gif|webp)[;,]/.test(v)||v.length>900000)throw fail(400,'Invalid or oversized image.');return v};
const need=(u,...r)=>{if(!r.includes(u.role))throw fail(403,FORBID)};
async function createComplaint(u,d){need(u,'Student','Faculty');
 if(!d.lab_id||!await one('SELECT id FROM labs WHERE id=?',+d.lab_id))throw fail(400,'Please select a laboratory.');
 const title=str(d.title,100,'Title'),desc=str(d.description,2000,'Description');if(!title)throw fail(400,'Issue title cannot be empty.');if(!desc)throw fail(400,'Issue description cannot be empty.');
 if(!CATS.includes(d.category)||!PRI.includes(d.priority))throw fail(400,'Invalid category or priority.');
 return await tx(async()=>{const id=await ins('complaints',{reported_by:u.id,reported_by_role:u.role,lab_id:+d.lab_id,category:d.category,equipment_number:str(d.equipment_number,40,'Equipment number'),title,description:desc,priority:d.priority,status:'Pending',technician_remark:'',resolution:'',image:img(d.image),created_at:now(),updated_at:now()});
 const cid='#LAB'+(100+id);await run('UPDATE complaints SET complaint_id=? WHERE id=?',cid,id);
 await notify(u.id,cid,`Complaint ${cid} has been submitted successfully.`);await hist(id,'Pending',u.id,'Reported');
 const labName=(await one('SELECT name FROM labs WHERE id=?',+d.lab_id)).name;for(const x of await all("SELECT id FROM users WHERE role IN('Technician','Admin') AND status='active'"))await notify(x.id,cid,`New ${d.priority}-priority issue ${cid} in ${labName}.`);
 return await one('SELECT * FROM complaints WHERE id=?',id)})}
// status workflow: what a technician may do next (admins may override anything)
const TR={Pending:['Assigned','In Progress'],Assigned:['In Progress'],'In Progress':['On Hold','Resolved'],'On Hold':['In Progress'],Resolved:[]};
const hist=(cid,status,by,note)=>run('INSERT INTO status_history(complaint_id,status,by_user,note,created_at)VALUES(?,?,?,?,?)',cid,status,by,note||'',now());
const activeAdmins=()=>all("SELECT id FROM users WHERE role='Admin' AND status='active'");
async function updateComplaint(u,id,d){need(u,'Technician','Admin');const c=await one('SELECT * FROM complaints WHERE id=?',id);if(!c)throw fail(404,'Complaint not found.');
 if(!STS.includes(d.status))throw fail(400,'Invalid status.');const resolution=str(d.resolution,2000,'Resolution'),remark=str(d.remark,2000,'Remark');
 if(u.role==='Technician'){
  if(c.assigned_to&&c.assigned_to!==u.id)throw fail(403,'This issue is assigned to another technician.');
  if(c.status==='Resolved')throw fail(403,'This complaint is already resolved. The reporter can reopen it, or an admin can change it.');
  if(d.status!==c.status&&!TR[c.status].includes(d.status))throw fail(400,`A "${c.status}" issue cannot be moved to "${d.status}".`)}
 if(d.status==='Resolved'&&!resolution)throw fail(400,'Please enter resolution details before resolving.');
 if(d.status==='On Hold'&&!remark)throw fail(400,'Please enter a reason in the remark box for putting the issue on hold.');
 let tech=d.assigned_to?+d.assigned_to:null;if(u.role==='Technician'){if(tech&&tech!==u.id)throw fail(403,'Only an admin can assign an issue to another technician.');if(!tech)tech=u.id}
 let t=null;if(tech){t=await one("SELECT * FROM users WHERE id=? AND role='Technician' AND status='active'",tech);if(!t)throw fail(400,'Invalid technician.')}
 let status=d.status;if(tech&&status==='Pending')status='Assigned';if(!tech&&status!=='Pending'&&status!=='Resolved')throw fail(400,'Assign a technician first.');
 const notes=[];if(tech!==c.assigned_to)notes.push(tech?'Assigned to '+t.name:'Unassigned');if(status!==c.status&&status==='Resolved')notes.push('Resolution: '+resolution);if(status!==c.status&&status==='On Hold')notes.push('Reason: '+remark);
 if(status!==c.status||tech!==c.assigned_to)await hist(id,status,u.id,notes.join(' · '));
 if(tech&&tech!==c.assigned_to){await notify(c.reported_by,c.complaint_id,`Complaint ${c.complaint_id} has been assigned to ${t.name}.`);if(tech!==u.id)await notify(tech,c.complaint_id,`Issue ${c.complaint_id} has been assigned to you.`);
  await emailUser(c.reported_by,`Complaint ${c.complaint_id} assigned`,`Your complaint ${c.complaint_id} (\"${c.title}\") has been assigned to ${t.name}.`);if(tech!==u.id)await emailUser(tech,`Issue ${c.complaint_id} assigned to you`,`Complaint ${c.complaint_id} (\"${c.title}\") has been assigned to you.`)}
 if(status==='Resolved'&&c.status!=='Resolved')await emailUser(c.reported_by,`Complaint ${c.complaint_id} resolved`,`Your complaint ${c.complaint_id} (\"${c.title}\") has been resolved.\n\nResolution: ${resolution}`);
 if(status!==c.status)await notify(c.reported_by,c.complaint_id,status==='Resolved'?`Complaint ${c.complaint_id} has been resolved.`:status==='On Hold'?`Complaint ${c.complaint_id} is on hold: ${remark}`:`Complaint ${c.complaint_id} is now ${status}.`);
 await run('UPDATE complaints SET status=?,assigned_to=?,technician_remark=?,resolution=?,updated_at=?,resolved_at=? WHERE id=?',status,tech,remark,resolution,now(),status==='Resolved'?(c.resolved_at||now()):null,id);
 return await one('SELECT * FROM complaints WHERE id=?',id)}
async function releaseComplaint(u,id,d){need(u,'Technician');const c=await one('SELECT * FROM complaints WHERE id=?',id);if(!c)throw fail(404,'Complaint not found.');
 if(c.assigned_to!==u.id)throw fail(403,'You can only release issues that are assigned to you.');if(c.status==='Resolved')throw fail(400,'A resolved issue cannot be released.');
 const reason=str(d.reason,500,'Reason');if(!reason)throw fail(400,'Please say why you are releasing this issue.');
 await run("UPDATE complaints SET assigned_to=NULL,status='Pending',updated_at=? WHERE id=?",now(),id);await hist(id,'Pending',u.id,`Released by ${u.name}: ${reason}`);
 for(const a of await activeAdmins())await notify(a.id,c.complaint_id,`${u.name} released issue ${c.complaint_id}: ${reason}`);
 for(const x of await all("SELECT id FROM users WHERE role='Technician' AND status='active' AND id<>?",u.id))await notify(x.id,c.complaint_id,`Issue ${c.complaint_id} is open again and needs a technician.`);
 await notify(c.reported_by,c.complaint_id,`Complaint ${c.complaint_id} is back in the queue and will be assigned to a technician.`);
 return await one('SELECT * FROM complaints WHERE id=?',id)}
async function reopenComplaint(u,id,d){need(u,'Student','Faculty');const c=await one('SELECT * FROM complaints WHERE id=?',id);if(!c||c.reported_by!==u.id)throw fail(404,'Complaint not found.');
 if(c.status!=='Resolved')throw fail(400,'Only a resolved complaint can be reopened.');
 const days=reopenDays(await setMap());if(!c.resolved_at||Date.now()-new Date(c.resolved_at).getTime()>days*864e5)throw fail(400,`A complaint can only be reopened within ${days} day${days>1?'s':''} of being resolved. Please report a new issue.`);
 const reason=str(d.reason,500,'Reason');if(!reason)throw fail(400,'Please tell us what is still wrong.');
 const t=c.assigned_to?await one("SELECT * FROM users WHERE id=? AND role='Technician' AND status='active'",c.assigned_to):null,status=t?'Assigned':'Pending';
 await run("UPDATE complaints SET status=?,assigned_to=?,resolution='',resolved_at=NULL,updated_at=? WHERE id=?",status,t?t.id:null,now(),id);await hist(id,status,u.id,`Reopened by ${u.name}: ${reason}`);
 const msg=`Complaint ${c.complaint_id} was reopened by ${u.name}: ${reason}`;if(t){await notify(t.id,c.complaint_id,msg);await emailUser(t.id,`Complaint ${c.complaint_id} reopened`,msg)}for(const a of await activeAdmins())await notify(a.id,c.complaint_id,msg);
 return await one('SELECT * FROM complaints WHERE id=?',id)}
const EM=/^\S+@\S+\.\S+$/;
async function saveUser(u,id,d){need(u,'Admin');const name=str(d.name,80,'Name'),email=str(d.email,120,'Email');if(!id&&String(d.password||'').length<8)throw fail(400,'Password must be at least 8 characters.');if(!name||!EM.test(email))throw fail(400,'Name and a valid email are required.');
 if(!ROLES.includes(d.role))throw fail(400,'Invalid role.');if(d.password&&String(d.password).length<8)throw fail(400,'Password must be at least 8 characters.');
 const cols=Object.values(IDF),set={name,email,role:d.role,department:str(d.department,80,'Department')};cols.forEach(c=>set[c]=null);set[IDF[d.role]]=str(d.idv,30,'ID');if(!set[IDF[d.role]])throw fail(400,'ID (RBT No. / Faculty / Technician / Admin ID) is required.');
 if(d.role==='Student'){set.year=d.year||'1st Year';set.division=d.division||'A'}
 if(id){if(id===u.id&&d.role!=='Admin')throw fail(400,'You cannot change your own role.');if(d.password)set.password_hash=hash(d.password);
  await run(`UPDATE users SET ${Object.keys(set).map(k=>k+'=?').join(',')} WHERE id=?`,...Object.values(set),id)}
 else{const un=String(d.username||'').toLowerCase();if(!/^[a-z0-9._]{3,30}$/.test(un))throw fail(400,'Username: min 3 chars (letters, digits, . _).');if(await one('SELECT id FROM users WHERE username=?',un))throw fail(400,'Username already exists.');
  await ins('users',{...set,username:un,password_hash:hash(d.password),profile_photo:avatar(name),status:'active',created_at:now()})}}
async function saveLab(u,id,d){need(u,'Admin');const name=str(d.name,80,'Lab name');if(!name)throw fail(400,'Lab name is required.');const st=['Operational','Under Maintenance','Closed'].includes(d.status)?d.status:'Operational';
 try{if(id)await run('UPDATE labs SET name=?,description=?,status=? WHERE id=?',name,str(d.description,200,'Description'),st,id);else await ins('labs',{name,description:str(d.description,200,'Description'),status:st,created_at:now()})}catch(e){if(/UNIQUE/i.test(e.message))throw fail(400,'A lab with this name already exists.');throw e}}
async function register(ip,d){const r=REG.get(ip);if(r&&r.t>Date.now()){if(r.n>=60)throw fail(429,'Too many registrations from this address. Try again later.');r.n++}else{if(REG.size>5000)REG.clear();REG.set(ip,{n:1,t:Date.now()+36e5})}
 const sm=await setMap();if(gs(sm,'registration','open')==='closed')throw fail(403,'Registration is closed. Please contact the lab admin.');
 const name=str(d.name,80,'Name'),email=str(d.email,120,'Email').toLowerCase(),un=String(d.username||'').trim().toLowerCase();
 if(!name||!EM.test(email))throw fail(400,'Name and a valid email are required.');const doms=regDomains(sm);if(doms.length&&!doms.includes(email.split('@').pop()))throw fail(400,`Please register with your college email (${doms.map(x=>'@'+x).join(', ')}).`);if(!['Student','Faculty','Technician'].includes(d.role))throw fail(400,'You can register as a Student, Faculty member or Technician. Admin accounts are created by an existing admin.');
 if(!/^[a-z0-9._]{3,30}$/.test(un))throw fail(400,'Username: min 3 chars (letters, digits, . _).');if(String(d.password||'').length<8)throw fail(400,'Password must be at least 8 characters.');
 const idv=str(d.idv,30,'ID');if(!idv)throw fail(400,'Your ID (RBT No. / Faculty ID / Technician ID) is required.');
 if(await one('SELECT id FROM users WHERE username=? OR lower(email)=?',un,email))throw fail(400,'An account with this username or email already exists.');
 const set={username:un,password_hash:hash(d.password),role:d.role,name,email,profile_photo:avatar(name),department:str(d.department,80,'Department'),status:'pending',created_at:now()};set[IDF[d.role]]=idv;if(d.role==='Student'){set.year=str(d.year,20,'Year')||'1st Year';set.division=str(d.division,5,'Division')||'A'}
 await tx(async()=>{await ins('users',set);for(const a of await all("SELECT id FROM users WHERE role='Admin' AND status='active'"))await notify(a.id,null,`New ${d.role} registration from ${name} (${un}) is awaiting approval.`)})}
async function forgot(ip,d){if(!mailer.enabled())throw fail(503,'Password reset by email is not available. Please contact your lab admin.');
 const email=String(d.email||'').trim().toLowerCase();if(!hit('f|'+ip,30)||!EM.test(email)||email.length>120||!hit('f|'+email,3))return; // always answer "ok" so accounts cannot be probed
 for(const x of await all("SELECT * FROM users WHERE lower(email)=? AND status='active'",email)){const tok=crypto.randomBytes(32).toString('hex');
  await run('DELETE FROM password_resets WHERE user_id=?',x.id);await run('INSERT INTO password_resets(token_hash,user_id,expires_at)VALUES(?,?,?)',sha(tok),x.id,Date.now()+30*6e4);
  mailer.send(email,'Reset your Smart Lab password',`Hi ${x.name},\n\nUse this link to set a new password (valid for 30 minutes, works once):\n${BASE}/#reset=${tok}\n\nIf you did not request this, you can ignore this email.`).catch(e=>console.error('Reset email failed:',e.message))}}
async function resetPassword(ip,d){const k='r|'+ip;if(limited(k))throw fail(429,'Too many attempts. Please try again later.');
 const pw=String(d.password||'');if(pw.length<8)throw fail(400,'Password must be at least 8 characters.');
 const row=await one('SELECT * FROM password_resets WHERE token_hash=?',sha(String(d.token||'')));if(!row||row.expires_at<Date.now()){badTry(k);throw fail(400,'This reset link is invalid or has expired.')}
 await tx(async()=>{await run('UPDATE users SET password_hash=? WHERE id=?',hash(pw),row.user_id);await run('DELETE FROM password_resets WHERE user_id=?',row.user_id)})}
async function saveSettings(u,d){need(u,'Admin');const days=Number(d.reopen_days);if(!Number.isInteger(days)||days<1||days>60)throw fail(400,'Reopen window must be a whole number of days between 1 and 60.');
 if(!['open','closed'].includes(d.registration))throw fail(400,'Registration must be open or closed.');
 const doms=String(d.allowed_domains||'').split(',').map(x=>x.trim().toLowerCase().replace(/^@/,'')).filter(Boolean);if(doms.length>10||doms.some(x=>!/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(x)))throw fail(400,'Allowed domains must look like jspm.edu, college.edu (max 10).');
 const cname=String(d.college_name||'').trim();if(cname.length>80)throw fail(400,'College name can be at most 80 characters.');
 if(d.logo!==undefined&&d.logo!==''&&!logoOk(d.logo))throw fail(400,'Logo must be a PNG, JPG or WebP image under about 400 KB.');
 await tx(async()=>{await setSet('reopen_days',days);await setSet('registration',d.registration);await setSet('allowed_domains',doms.join(','));await setSet('college_name',cname);
  if(d.logo!==undefined){await setSet('logo',d.logo);await setSet('logo_v',Date.now())}});return settingsView(await setMap())}
async function testEmail(u){need(u,'Admin');if(!mailer.enabled())throw fail(400,'Email is not configured. Set RESEND_API_KEY, MAIL_FROM and BASE_URL on the server.');
 const real=!!(MAIL_KEY&&MAIL_FROM);try{await mailer.send(u.email,'Smart Lab test email',`Hi ${u.name},\n\nThis is a test email from the Smart Lab Maintenance System. If you can read this, email is working.`)}catch(e){throw fail(502,'The email service rejected the message: '+e.message)}
 return{ok:true,to:u.email,mode:real?'sent':'console'}}
async function setup(d){await tx(async()=>{if(!(await noUsers()))throw fail(403,'Setup is already complete.');const name=str(d.name,80,'Name'),email=str(d.email,120,'Email'),un=String(d.username||'').trim().toLowerCase();
 if(!name||!EM.test(email))throw fail(400,'Name and a valid email are required.');if(!/^[a-z0-9._]{3,30}$/.test(un))throw fail(400,'Username: 3-30 chars (letters, digits, . _).');if(String(d.password||'').length<8)throw fail(400,'Password must be at least 8 characters.');await createAdmin(name,un,email,d.password)})}
/* ---- HTTP ---- */
const routes=[
 ['POST',/^\/api\/login$/,async(req,u,b,m,res)=>{const un=String(b.username||'').trim().toLowerCase(),key=ipOf(req)+'|'+un;
  if(limited(key))throw fail(429,'Too many failed attempts. Please try again in 15 minutes.');
  const x=await one('SELECT * FROM users WHERE username=? OR lower(email)=?',un,un);
  if(!x||x.role!==b.role||!verify(String(b.password||''),x.password_hash)){badTry(key);throw fail(401,'Invalid username or password.')}
  FAILS.delete(key);if(x.status==='pending')throw fail(403,'Your registration is awaiting admin approval.');if(x.status!=='active')throw fail(403,'This account has been deactivated.');
  res.setHeader('Set-Cookie',cookie(x));return{ok:true}}],
 ['POST',/^\/api\/logout$/,async(req,u,b,m,res)=>{res.setHeader('Set-Cookie',`sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${PROD?'; Secure':''}`);return{ok:true}}],
 ['GET',/^\/api\/health$/,async()=>{const m=await setMap();return{status:'ok',time:now(),db:PG?'postgres':'sqlite',demo:!!(await one("SELECT 1 a FROM users WHERE username='admin001'")),mail:mailer.enabled(),setup:await noUsers(),dev:DEV,registration:gs(m,'registration','open'),domains:regDomains(m).join(', '),...brand(m)}}],
 ['POST',/^\/api\/setup$/,async(req,u,b)=>(await setup(b),{ok:true})],
 ['POST',/^\/api\/forgot$/,async(req,u,b)=>(await forgot(ipOf(req),b),{ok:true})],
 ['POST',/^\/api\/reset-password$/,async(req,u,b)=>(await resetPassword(ipOf(req),b),{ok:true})],
 ['POST',/^\/api\/register$/,async(req,u,b)=>(await register(ipOf(req),b),{ok:true})],
 ['GET',/^\/api\/state$/,async(r,u)=>state(u),1],
 ['POST',/^\/api\/complaints$/,async(r,u,b)=>createComplaint(u,b),1],
 ['PATCH',/^\/api\/complaints\/(\d+)$/,async(r,u,b,m)=>tx(()=>updateComplaint(u,+m[1],b)),1],
 ['POST',/^\/api\/notifications\/read$/,async(r,u,b)=>{await run(`UPDATE notifications SET is_read=1 WHERE user_id=?${b.id?' AND id=?':''}`,...(b.id?[u.id,+b.id]:[u.id]));return{ok:true}},1],
 ['PUT',/^\/api\/profile$/,async(r,u,b,m,res)=>{const name=str(b.name,80,'Name'),email=str(b.email,120,'Email');if(!name||!EM.test(email))throw fail(400,'Enter a valid name and email.');
  if(b.password&&String(b.password).length<6)throw fail(400,'Password must be at least 6 characters.');
  await run('UPDATE users SET name=?,email=?,profile_photo=COALESCE(?,profile_photo),password_hash=COALESCE(?,password_hash) WHERE id=?',name,email,img(b.photo),b.password?hash(b.password):null,u.id);if(b.password)res.setHeader('Set-Cookie',cookie(await one('SELECT * FROM users WHERE id=?',u.id)));return{ok:true}},1],
 ['POST',/^\/api\/users$/,async(r,u,b)=>(await saveUser(u,0,b),{ok:true}),1],
 ['PUT',/^\/api\/users\/(\d+)$/,async(r,u,b,m)=>(await saveUser(u,+m[1],b),{ok:true}),1],
 ['POST',/^\/api\/users\/(\d+)\/toggle$/,async(r,u,b,m)=>{need(u,'Admin');if(+m[1]===u.id)throw fail(400,'You cannot deactivate yourself.');await run("UPDATE users SET status=CASE status WHEN 'active' THEN 'inactive' ELSE 'active' END WHERE id=?",+m[1]);return{ok:true}},1],
 ['POST',/^\/api\/users\/(\d+)\/reject$/,async(r,u,b,m)=>{need(u,'Admin');const x=await one('SELECT status FROM users WHERE id=?',+m[1]);if(!x||x.status!=='pending')throw fail(400,'Only pending registrations can be rejected.');await run('DELETE FROM users WHERE id=?',+m[1]);return{ok:true}},1],
 ['POST',/^\/api\/complaints\/(\d+)\/release$/,async(r,u,b,m)=>tx(()=>releaseComplaint(u,+m[1],b)),1],
 ['POST',/^\/api\/complaints\/(\d+)\/reopen$/,async(r,u,b,m)=>tx(()=>reopenComplaint(u,+m[1],b)),1],
 ['GET',/^\/api\/complaints\/(\d+)\/history$/,async(r,u,b,m)=>{const c=await one('SELECT reported_by FROM complaints WHERE id=?',+m[1]);if(!c||(['Student','Faculty'].includes(u.role)&&c.reported_by!==u.id))throw fail(404,'Complaint not found.');
  return await all('SELECT h.status,h.note,h.created_at,x.name AS by_name,x.role AS by_role FROM status_history h LEFT JOIN users x ON x.id=h.by_user WHERE h.complaint_id=? ORDER BY h.id',+m[1])},1],
 ['PUT',/^\/api\/settings$/,async(r,u,b)=>saveSettings(u,b),1],
 ['POST',/^\/api\/settings\/test-email$/,async(r,u)=>testEmail(u),1],
 ['POST',/^\/api\/labs$/,async(r,u,b)=>(await saveLab(u,0,b),{ok:true}),1],
 ['PUT',/^\/api\/labs\/(\d+)$/,async(r,u,b,m)=>(await saveLab(u,+m[1],b),{ok:true}),1],
 ['POST',/^\/api\/reset$/,async(r,u)=>{need(u,'Admin');if(!ALLOW_RESET)throw fail(403,'Reset is only available in demo mode (DEMO=1).');await tx(seed);return{ok:true}},1]];
const MIME={'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon'};
const server=http.createServer(async(req,res)=>{await ready;const url=new URL(req.url,'http://x'),p=url.pathname;
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Referrer-Policy','no-referrer');
 res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
 if(PROD)res.setHeader('Strict-Transport-Security','max-age=31536000; includeSubDomains');if(p.startsWith('/api/'))res.setHeader('Cache-Control','no-store');
 const send=(c,o,h={})=>{res.writeHead(c,{'Content-Type':'application/json',...h});res.end(JSON.stringify(o))};
 if(p.startsWith('/api/')){try{const r=routes.find(x=>x[0]===req.method&&x[1].test(p));if(!r)throw fail(404,'Not found.');
   const u=await readToken(req);if(r[3]&&!u)throw fail(401,'Please log in.');
   let body='';for await(const c of req){body+=c;if(body.length>1.5e6)throw fail(413,'Request too large.')}let b={};if(body){try{b=JSON.parse(body)}catch{throw fail(400,'Invalid JSON.')}}
   send(200,await r[2](req,u,b,p.match(r[1]),res))}catch(e){const ok=Number.isInteger(e.code);if(!ok)console.error(e);send(ok?e.code:500,{error:ok?e.message:'Server error.'})}return}
 if(p==='/brand/logo'&&req.method==='GET'){const m=LOGO_RE.exec(await getSet('logo',''));res.setHeader('Cache-Control','no-cache');
   if(m){res.writeHead(200,{'Content-Type':m[1]});return res.end(Buffer.from(m[2],'base64'))}
   res.writeHead(200,{'Content-Type':'image/png'});return res.end(fs.readFileSync(path.join(__dirname,'public','logo.png')))}
  const f=path.join(__dirname,'public',p==='/'?'index.html':p);if(!f.startsWith(path.join(__dirname,'public')+path.sep)||!fs.existsSync(f)||fs.statSync(f).isDirectory()){res.writeHead(404);return res.end('Not found')}
 res.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(res)});
if(require.main===module)server.listen(PORT,()=>console.log(`Lab Maintenance running on http://localhost:${PORT}  (database: ${PG?'Postgres/Supabase':'SQLite'})`));
server.mailer=mailer;server.db=db;server.run=run;server.ready=ready;module.exports=server;
